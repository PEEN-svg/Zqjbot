# **Ultra N-system Bot By ニロ#3892**

**ニロ Meen Niro 🙃**

## 💨 Run the projects

Replit: [![Run on Repl.it](https://repl.it/@NIR0/N-System-v3#index.js)]

### ⚡ Installation

go to `Bot_Config` folder and edit config.json file

```js
{
  "ytapi_key": "Youtube API KEY",
  "token": "Discord TOKEN",
  "prefix": "Bot PREFIX"
}
```

## ✨ Mad By

```@ニロ#3892```

## 🌀 Support

[![Naar Server](https://media.discordapp.net/attachments/756329106953601225/795743580492267560/Screenshot_1.png)](https://discord.gg/S2edTcfWWz)

[![NCR Codes](https://media.discordapp.net/attachments/756329106953601225/795742444854837280/098941bdba1a94f9f7d9b22e1b601329.png)](https://discord.gg/7C2MnFTwcC)
