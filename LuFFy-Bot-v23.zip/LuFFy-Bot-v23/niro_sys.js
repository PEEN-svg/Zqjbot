// [    --- <!-- Data --!> ---    ] \\
const line_pic = "";
const down_vote = "👎";
const up_vote = "👍";
const error = "❌";
const timeing = "⏱";
const success = "✅";
const lodeing = "🤔";
const notes = "🎶";
const stop = "⏹";
const sos = "🆘";
const skippeded = "⏭️";
const repeating = "🔁";
const resumed = "▶";
const pauseeded = "⏸";

// [    --- <!-- The Sourse Code --!> ---    ] \\

var _0x8d47=["\x65\x78\x70\x72\x65\x73\x73","\x2F","\x5C\x22\x53\x75\x70\x65\x72\x20\x4E\x49\x52\x30\x20\x53\x79\x73\x74\x65\x6D\x5C\x22","\x73\x65\x6E\x64","\x67\x65\x74","\x4E\x49\x52\x30\x20\x53\x79\x73\x74\x65\x6D\x20\x53\x74\x61\x72\x74\x65\x64\x2E\x2E\x2E","\x6C\x6F\x67","\x6C\x69\x73\x74\x65\x6E"];const express=require(_0x8d47[0]);const app=express();const port=3000;app[_0x8d47[4]](_0x8d47[1],(_0x77b1x4,_0x77b1x5)=>{return _0x77b1x5[_0x8d47[3]](`${_0x8d47[2]}`)});app[_0x8d47[7]](port,()=>{return console[_0x8d47[6]](`${_0x8d47[5]}`)})

var _0x8fc5=["\x64\x69\x73\x63\x6F\x72\x64\x2E\x6A\x73","\x61\x6C\x6C","\x73\x69\x6D\x70\x6C\x65\x2D\x79\x6F\x75\x74\x75\x62\x65\x2D\x61\x70\x69","\x79\x74\x64\x6C\x2D\x63\x6F\x72\x65","\x71\x75\x69\x63\x6B\x2E\x64\x62","\x64\x61\x74\x65\x66\x6F\x72\x6D\x61\x74","\x6D\x6F\x6D\x65\x6E\x74","\x66\x73","\x63\x68\x61\x6C\x6B","\x65\x6E\x6D\x61\x70","\x63\x61\x6E\x76\x61\x63\x6F\x72\x64","\x70\x6F\x69\x6E\x74\x73","\x2E\x2F\x42\x6F\x74\x5F\x43\x6F\x6E\x66\x69\x67\x2F\x72\x6F\x6F\x6D\x73\x2E\x6A\x73\x6F\x6E","\x2E\x2F\x42\x6F\x74\x5F\x43\x6F\x6E\x66\x69\x67\x2F\x63\x6F\x6E\x66\x69\x67\x2E\x6A\x73\x6F\x6E"];const {Client,Util,MessageEmbed}=require(_0x8fc5[0]);const client= new Client({disableMentions:_0x8fc5[1]});const YouTube=require(_0x8fc5[2]);const ytdl=require(_0x8fc5[3]);const db=require(_0x8fc5[4]);const dateFormat=require(_0x8fc5[5]);const moment=require(_0x8fc5[6]);const fs=require(_0x8fc5[7]);const chalk=require(_0x8fc5[8]);let Enmap=require(_0x8fc5[9]);let canvacord=require(_0x8fc5[10]);const Discord=require(_0x8fc5[0]);client[_0x8fc5[11]]=  new Enmap({name:_0x8fc5[11]});const {welcome_room,invite_room}=require(_0x8fc5[12]);const {prefix,token,ytapi_key}=require(_0x8fc5[13])

var _0xd9a2=["\x72\x65\x61\x64\x79","\x68\x65\x6C\x70","\x50\x4C\x41\x59\x49\x4E\x47","\x73\x65\x74\x41\x63\x74\x69\x76\x69\x74\x79","\x75\x73\x65\x72","\x42\x6F\x74\x20\x73\x74\x61\x72\x74\x65\x64\x21\x0D\x0A\x20\x20\x20\x20\x20\x20\x20\x20\x3E\x20\x55\x73\x65\x72\x73\x3A\x20","\x73\x69\x7A\x65","\x63\x61\x63\x68\x65","\x75\x73\x65\x72\x73","\x0D\x0A\x20\x20\x20\x20\x20\x20\x20\x20\x3E\x20\x43\x68\x61\x6E\x6E\x65\x6C\x73\x3A\x20","\x63\x68\x61\x6E\x6E\x65\x6C\x73","\x0D\x0A\x20\x20\x20\x20\x20\x20\x20\x20\x3E\x20\x53\x65\x72\x76\x65\x72\x73\x3A\x20","\x67\x75\x69\x6C\x64\x73","\x0D\x0A\x20\x20\x20\x20\x20\x20\x20\x20\x3E\x20\x4E\x61\x6D\x65\x3A\x20","\x75\x73\x65\x72\x6E\x61\x6D\x65","\x0D\x0A\x20\x20\x20\x20\x20\x20\x20\x20\x3E\x20\x44\x65\x76\x65\x6C\x6F\x70\x65\x72\x3A\x20\x40\u30CB\u30ED\x23\x33\x38\x39\x32\x0D\x0A\x20\x20\x20\x20\x20\x20\x20\x20\x3E\x20\x53\x75\x70\x70\x6F\x72\x74\x3A\x20\x68\x74\x74\x70\x73\x3A\x2F\x2F\x64\x69\x73\x63\x6F\x72\x64\x2E\x67\x67\x2F\x63\x74\x45\x54\x56\x67\x76\x70\x75\x53","\x67\x72\x65\x65\x6E","\x6C\x6F\x67","\x6F\x6E"];client[_0xd9a2[18]](_0xd9a2[0],async ()=>{client[_0xd9a2[4]][_0xd9a2[3]](prefix+ _0xd9a2[1],{type:_0xd9a2[2]});console[_0xd9a2[17]](chalk[_0xd9a2[16]](`${_0xd9a2[5]}${client[_0xd9a2[8]][_0xd9a2[7]][_0xd9a2[6]]}${_0xd9a2[9]}${client[_0xd9a2[10]][_0xd9a2[7]][_0xd9a2[6]]}${_0xd9a2[11]}${client[_0xd9a2[12]][_0xd9a2[7]][_0xd9a2[6]]}${_0xd9a2[13]}${client[_0xd9a2[4]][_0xd9a2[14]]}${_0xd9a2[15]}`))})
var _0x2956=["\x77\x61\x72\x6E","\x6F\x6E","\x65\x72\x72\x6F\x72","\x72\x65\x61\x64\x79","\x5B\x52\x45\x41\x44\x59\x5D\x20","\x74\x61\x67","\x75\x73\x65\x72","\x20\x68\x61\x73\x20\x62\x65\x65\x6E\x20\x73\x75\x63\x63\x65\x73\x73\x66\x75\x6C\x6C\x79\x20\x62\x6F\x6F\x74\x65\x64\x20\x75\x70\x21","\x6C\x6F\x67"];const PREFIX=prefix;const youtube= new YouTube(ytapi_key);const queue= new Map();client[_0x2956[1]](_0x2956[0],console[_0x2956[0]]);client[_0x2956[1]](_0x2956[2],console[_0x2956[2]]);client[_0x2956[1]](_0x2956[3],()=>{console[_0x2956[8]](`${_0x2956[4]}${client[_0x2956[6]][_0x2956[5]]}${_0x2956[7]}`)})

const cooldown_command = new Set();


client.on("message", async msg => {
            // eslint-disable-line
            if (msg.author.bot) return;
            if (!msg.content.startsWith(PREFIX)) return;

            const args = msg.content.split(" ");
            const searchString = args.slice(1).join(" ");
            const url = args[1] ? args[1].replace(/<(.+)>/g, "$1") : "";
            const serverQueue = queue.get(msg.guild.id);

            let command = msg.content.toLowerCase().split(" ")[0];
            command = command.slice(PREFIX.length);

            if (command === "play" || command === "p" || command === "شغل") {
                const voiceChannel = msg.member.voice.channel;
                if (!voiceChannel)
                    return msg.channel.send({
                        embed: {
                            color: "RED",
                            description: "Be in a Voice Channel First!"
                        }
                    });
                const permissions = voiceChannel.permissionsFor(msg.client.user);
                if (!permissions.has("CONNECT")) {
                    return msg.channel.send({
                        embed: {
                            color: "RED",
                            description: "Sorry, but I need a **`CONNECT`** permission to proceed!"
                        }
                    });
                }
                if (!permissions.has("SPEAK")) {
                    return msg.channel.send({
                        embed: {
                            color: "RED",
                            description: "Sorry, but I need a **`SPEAK`** permission to proceed!"
                        }
                    });
                }
                if (!url || !searchString)
                    return msg.channel.send({
                        embed: {
                            color: "RED",
                            description: "Please input link/title to play music"
                        }
                    });
                if (url.match(/^https?:\/\/(www.youtube.com|youtube.com)\/playlist(.*)$/)) {
                    const playlist = await youtube.getPlaylist(url);
                    const videos = await playlist.getVideos();
                    for (const video of Object.values(videos)) {
                        const video2 = await youtube.getVideoByID(video.id); // eslint-disable-line no-await-in-loop
                        await handleVideo(video2, msg, voiceChannel, true); // eslint-disable-line no-await-in-loop
                    }
                    return msg.channel.send({
                        embed: {
                            color: "GREEN",
                            description: `${success}  **|**  Playlist: **\`${playlist.title}\`** has been added to the queue`
                        }
                    });
                } else {
                    try {
                        var video = await youtube.getVideo(url);
                    } catch (error) {
                        try {
                            var videos = await youtube.searchVideos(searchString, 10);
                            var video = await youtube.getVideoByID(videos[0].id);
                            if (!video)
                                return msg.channel.send({
                                    embed: {
                                        color: "RED",
                                        description: `${sos}  **|**  I could not obtain any search results`
                                    }
                                });
                        } catch (err) {
                            console.error(err);
                            return msg.channel.send({
                                embed: {
                                    color: "RED",
                                    description: `${sos}  **|**  I could not obtain any search results`
                                }
                            });
                        }
                    }
                    return handleVideo(video, msg, voiceChannel);
                }
            }
            if (command === "search" || command === "sc") {
                const voiceChannel = msg.member.voice.channel;
                if (!voiceChannel)
                    return msg.channel.send({
                        embed: {
                            color: "RED",
                            description: "I'm sorry, but you need to be in a voice channel to play a music!"
                        }
                    });
                const permissions = voiceChannel.permissionsFor(msg.client.user);
                if (!permissions.has("CONNECT")) {
                    return msg.channel.send({
                        embed: {
                            color: "RED",
                            description: "Sorry, but I need a **`CONNECT`** permission to proceed!"
                        }
                    });
                }
                if (!permissions.has("SPEAK")) {
                    return msg.channel.send({
                        embed: {
                            color: "RED",
                            description: "Sorry, but I need a **`SPEAK`** permission to proceed!"
                        }
                    });
                }
                if (!url || !searchString)
                    return msg.channel.send({
                        embed: {
                            color: "RED",
                            description: "Please input link/title to search music"
                        }
                    });
                if (url.match(/^https?:\/\/(www.youtube.com|youtube.com)\/playlist(.*)$/)) {
                    const playlist = await youtube.getPlaylist(url);
                    const videos = await playlist.getVideos();
                    for (const video of Object.values(videos)) {
                        const video2 = await youtube.getVideoByID(video.id); // eslint-disable-line no-await-in-loop
                        await handleVideo(video2, msg, voiceChannel, true); // eslint-disable-line no-await-in-loop
                    }
                    return msg.channel.send({
                        embed: {
                            color: "GREEN",
                            description: `${success}  **|**  Playlist: **\`${playlist.title}\`** has been added to the queue`
                        }
                    });
                } else {
                    try {
                        var video = await youtube.getVideo(url);
                    } catch (error) {
                        try {
                            var videos = await youtube.searchVideos(searchString, 10);
                            let index = 0;
                            let embedPlay = new MessageEmbed()
                                .setColor("BLUE")
                                .setAuthor("Search results", msg.author.displayAvatarURL())
                                .setDescription(
                                    `${videos
                .map(video2 => `**\`${++index}\`  |**  ${video2.title}`)
                .join("\n")}`
            )
            .setFooter(
              "Please choose one of the following 10 results, this embed will auto-deleted in 15 seconds"
            );
          // eslint-disable-next-line max-depth
          msg.channel.send(embedPlay).then(m =>
            m.delete({
              timeout: 15000
            })
          );
          try {
            var response = await msg.channel.awaitMessages(
              message2 => message2.content > 0 && message2.content < 11,
              {
                max: 1,
                time: 15000,
                errors: ["time"]
              }
            );
          } catch (err) {
            console.error(err);
            return msg.channel.send({
              embed: {
                color: "RED",
                description:
                  "The song selection time has expired in 15 seconds, the request has been canceled."
              }
            });
          }
          const videoIndex = parseInt(response.first().content);
          var video = await youtube.getVideoByID(videos[videoIndex - 1].id);
        } catch (err) {
          console.error(err);
          return msg.channel.send({
            embed: {
              color: "RED",
              description: `${sos}  **|**  I could not obtain any search results`
            }
          });
        }
      }
      response.delete();
      return handleVideo(video, msg, voiceChannel);
    }
  } else if (command === "skip") {
    if (!msg.member.voice.channel)
      return msg.channel.send({
        embed: {
          color: "RED",
          description:
            "I'm sorry, but you need to be in a voice channel to skip a music!"
        }
      });
    if (!serverQueue)
      return msg.channel.send({
        embed: {
          color: "RED",
          description: "There is nothing playing that I could skip for you"
        }
      });
    serverQueue.connection.dispatcher.end(
      "[runCmd] Skip command has been used"
    );
    return msg.channel.send({
      embed: {
        color: "GREEN",
        description: `${skippeded}  **|**  I skipped the song for you`
      }
    });
  } else if (command === "stop") {
    if (!msg.member.voice.channel)
      return msg.channel.send({
        embed: {
          color: "RED",
          description:
            "I'm sorry but you need to be in a voice channel to play music!"
        }
      });
    if (!serverQueue)
      return msg.channel.send({
        embed: {
          color: "RED",
          description: "There is nothing playing that I could stop for you"
        }
      });
    serverQueue.songs = [];
    serverQueue.connection.dispatcher.end(
      "[runCmd] Stop command has been used"
    );
    return msg.channel.send({
      embed: {
        color: "GREEN",
        description: `${stop}  **|**  Deleting queues and leaving voice channel...`
      }
    });
  } else if (command === "volume" || command === "vol") {
    if (!msg.member.voice.channel)
      return msg.channel.send({
        embed: {
          color: "RED",
          description:
            "I'm sorry, but you need to be in a voice channel to set a volume!"
        }
      });
    if (!serverQueue)
      return msg.channel.send({
        embed: {
          color: "RED",
          description: "There is nothing playing"
        }
      });
    if (!args[1])
      return msg.channel.send({
        embed: {
          color: "BLUE",
          description: `The current volume is: **\`${serverQueue.volume}%\`**`
        }
      });
    if (isNaN(args[1]) || args[1] > 100)
      return msg.channel.send({
        embed: {
          color: "RED",
          description:
            "Volume only can be set in a range of **`1`** - **`100`**"
        }
      });
    serverQueue.volume = args[1];
    serverQueue.connection.dispatcher.setVolume(args[1] / 100);
    return msg.channel.send({
      embed: {
        color: "GREEN",
        description: `I set the volume to: **\`${args[1]}%\`**`
      }
    });
  } else if (command === "nowplaying" || command === "np") {
    if (!serverQueue)
      return msg.channel.send({
        embed: {
          color: "RED",
          description: "There is nothing playing"
        }
      });
    return msg.channel.send({
      embed: {
        color: "BLUE",
        description: `${notes}  **|**  Now Playing: **\`${serverQueue.songs[0].title}\`**`
      }
    });
  } else if (command === "queue" || command === "q") {
    let songsss = serverQueue.songs.slice(1);

    let number = songsss.map((x, i) => `${i + 1} - ${x.title}`);
    number = chunk(number, 5);

    let index = 0;
    if (!serverQueue)
      return msg.channel.send({
        embed: {
          color: "RED",
          description: "There is nothing playing"
        }
      });
    let embedQueue = new MessageEmbed()
      .setColor("BLUE")
      .setAuthor("Song queue", msg.author.displayAvatarURL())
      .setDescription(number[index].join("\n"))
      .setFooter(
        `• Now Playing: ${serverQueue.songs[0].title} | Page ${index + 1} of ${
        number.length
        }`
      );
    const m = await msg.channel.send(embedQueue);

    if (number.length !== 1) {
      await m.react("⬅");
      await m.react("🛑");
      await m.react("➡");
      async function awaitReaction() {
        const filter = (rect, usr) =>
          ["⬅", "🛑", "➡"].includes(rect.emoji.name) &&
          usr.id === msg.author.id;
        const response = await m.awaitReactions(filter, {
          max: 1,
          time: 30000
        });
        if (!response.size) {
          return undefined;
        }
        const emoji = response.first().emoji.name;
        if (emoji === "⬅") index--;
        if (emoji === "🛑") m.delete();
        if (emoji === "➡") index++;

        if (emoji !== "🛑") {
          index = ((index % number.length) + number.length) % number.length;
          embedQueue.setDescription(number[index].join("\n"));
          embedQueue.setFooter(`Page ${index + 1} of ${number.length}`);
          await m.edit(embedQueue);
          return awaitReaction();
        }
      }
      return awaitReaction();
    }
  } else if (command === "pause") {
    if (serverQueue && serverQueue.playing) {
      serverQueue.playing = false;
      serverQueue.connection.dispatcher.pause();
      return msg.channel.send({
        embed: {
          color: "GREEN",
          description: `${pauseeded}  **|**  Paused the music for you`
        }
      });
    }
    return msg.channel.send({
      embed: {
        color: "RED",
        description: "There is nothing playing"
      }
    });
  } else if (command === "resume") {
    if (serverQueue && !serverQueue.playing) {
      serverQueue.playing = true;
      serverQueue.connection.dispatcher.resume();
      return msg.channel.send({
        embed: {
          color: "GREEN",
          description: `${resumed}  **|**  Resumed the music for you`
        }
      });
    }
    return msg.channel.send({
      embed: {
        color: "RED",
        description: "There is nothing playing"
      }
    });
  } else if (command === "loop") {
    if (serverQueue) {
      serverQueue.loop = !serverQueue.loop;
      return msg.channel.send({
        embed: {
          color: "GREEN",
          description: `${repeating}  **|**  Loop is **\`${
            serverQueue.loop === true ? "enabled" : "disabled"
            }\`**`
        }
      });
    }
    return msg.channel.send({
      embed: {
        color: "RED",
        description: "There is nothing playing"
      }
    });
  }
});

async function handleVideo(video, msg, voiceChannel, playlist = false) {
  const serverQueue = queue.get(msg.guild.id);
  const song = {
    id: video.id,
    title: Util.escapeMarkdown(video.title),
    url: `https://www.youtube.com/watch?v=${video.id}`
  };
  if (!serverQueue) {
    const queueConstruct = {
      textChannel: msg.channel,
      voiceChannel: voiceChannel,
      connection: null,
      songs: [],
      volume: 100,
      playing: true,
      loop: false
    };
    queue.set(msg.guild.id, queueConstruct);
    queueConstruct.songs.push(song);

    try {
      var connection = await voiceChannel.join();
      queueConstruct.connection = connection;
      play(msg.guild, queueConstruct.songs[0]);
    } catch (error) {
      console.error(
        `[ERROR] I could not join the voice channel, because: ${error}`
      );
      queue.delete(msg.guild.id);
      return msg.channel.send({
        embed: {
          color: "RED",
          description: `I could not join the voice channel, because: **\`${error}\`**`
        }
      });
    }
  } else {
    serverQueue.songs.push(song);
    if (playlist) return;
    else
      return msg.channel.send({
        embed: {
          color: "GREEN",
          description: `${success}  **|**  **\`${song.title}\`** has been added to the queue`
        }
      });
  }
  return;
}

function chunk(array, chunkSize) {
  const temp = [];
  for (let i = 0; i < array.length; i += chunkSize) {
    temp.push(array.slice(i, i + chunkSize));
  }
  return temp;
}

function play(guild, song) {
  const serverQueue = queue.get(guild.id);

  if (!song) {
    serverQueue.voiceChannel.leave();
    return queue.delete(guild.id);
  }

  const dispatcher = serverQueue.connection
    .play(ytdl(song.url))
    .on("finish", () => {
      const shiffed = serverQueue.songs.shift();
      if (serverQueue.loop === true) {
        serverQueue.songs.push(shiffed);
      }
      play(guild, serverQueue.songs[0]);
    })
    .on("error", error => console.error(error));
  dispatcher.setVolume(serverQueue.volume / 100);

  serverQueue.textChannel.send({
    embed: {
      color: "BLUE",
      description: `${notes}  **|**  Start Playing: **\`${song.title}\`**`
    }
  });
}

process.on("unhandledRejection", (reason, promise) => {
  try {
    console.error(
      "Unhandled Rejection at: ",
      promise,
      "reason: ",
      reason.stack || reason
    );
  } catch {
    console.error(reason);
  }
});

process.on("uncaughtException", err => {
  console.error(`Caught exception: ${err}`);
  process.exit(1);
});

client.on("message", msg => {
  if (msg.content.startsWith(prefix + "help play")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: play**
          
              play a music.
              
              **Usage:**
              ${prefix}play (url/name)
              
              **Example:**
              ${prefix}play https://youtu.be/DnJ5Rgstjog
              ${prefix}play الجميزا
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
client.on("message", msg => {
  if (msg.content.startsWith(prefix + "help stop")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: stop**
          
              stop a music.
              
              **Usage:**
              ${prefix}stop
              
              **Example:**
              ${prefix}stop
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
client.on("message", msg => {
  if (msg.content.startsWith(prefix + "help search")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: search**
          
              search for a music.
              
              **Usage:**
              ${prefix}serch (name)
              
              **Example:**
              ${prefix}search الجميزا
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
              }
})
client.on("message", msg => {
  if (msg.content.startsWith(prefix + "help skip")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: skip**
          
              skip music.
              
              **Usage:**
              ${prefix}skip
              
              **Example:**
              ${prefix}skip
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
client.on("message", msg => {
  if (msg.content.startsWith(prefix + "help pause")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                    if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: pause**
          
              pause a music.
              
              **Usage:**
              ${prefix}pause
              
              **Example:**
              ${prefix}pause
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
client.on("message", msg => {
  if (msg.content.startsWith(prefix + "help resume")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: resume**
          
              resume a music.
              
              **Usage:**
              ${prefix}resume
              
              **Example:**
              ${prefix}resume
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
client.on("message", msg => {
  if (msg.content.startsWith(prefix + "help volume")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: volume**
          
              change music volume.
              
              **Usage:**
              ${prefix}volume (num)
              
              **Example:**
              ${prefix}volume 10
              ${prefix}volume 50
              ${prefix}volume 90
              
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
client.on("message", msg => {
  if (msg.content.startsWith(prefix + "help queue")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: queue**
          
              view the music queue.
              
              **Usage:**
              ${prefix}queue
              
              **Example:**
              ${prefix}queue
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
// <!-- Profile --!>
client.on("message", async msg => {
  let args = msg.content.split(" ");
  if (msg.content.startsWith(prefix + "profile")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    let member = msg.mentions.users.first();

    if (args[0] && !args[1]) {
      msg.channel.startTyping();
      setTimeout(() => {
        msg.channel.stopTyping();
      }, Math.random() * (1 - 3) + 1 * 1000);
      msg.channel.send({
        files: [
          {
            name: "cutie=HyPeD.png",
            attachment: `https://api.probot.io/profile/${msg.author.id}`
          }
        ]
      });
    }
    if (member) {
      msg.channel.startTyping();
      setTimeout(() => {
        msg.channel.stopTyping();
      }, Math.random() * (1 - 3) + 1 * 1000);
                          if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
      msg.channel.send({
        files: [
          {
            name: "cutie=HyPeD.png",
            attachment: `https://api.probot.io/profile/${member.id}`
          }
        ]
      });
                      cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
    } else if (args[1] && !member) {
      client.users.fetch(args[1]).then(userr => {
        msg.channel.stopTyping();
        setTimeout(() => {
          msg.channel.stopTyping();
        }, Math.random() * (1 - 3) + 1 * 1000);
                            if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
        msg.channel.send({
          files: [
            {
              name: "cutie=HyPeD.png",
              attachment: `https://api.probot.io/profile/${userr.id}`
            }
          ]
        });
                        cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
      });
    }
  }
});
//help
client.on("message", (msg) => {
  if (msg.content === prefix + "اوامر") {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing data ...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
    let help = new Discord.MessageEmbed()
      .setThumbnail(msg.member.user.avatarURL({ format: "gif", format: "png", dynamic: true, size: 1024 }))
      .setAuthor("Bot Orders")
      .setTitle("مطور البوت:LuFFy#9892")
      
      .addField(prefix + `admin`, `Admin Commands`, true)
      .addField(prefix + `public`, `Public Commands`, true)
      .addField(prefix + `music`, `Music Commands`, true)
      .addField(prefix + `games`, `Games Commands`, true)
      .setFooter(`Request By ${msg.author.tag}`)
      .setTimestamp()
              if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(help)
                cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
client.on("message", (msg) => {
  if (msg.content === prefix + "admin") {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing data ...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
    let admin = new Discord.MessageEmbed()
      .setThumbnail(msg.member.user.avatarURL({ format: "gif", format: "png", dynamic: true, size: 1024 }))
      .setAuthor("Admins Orders")
      .addField(prefix + "ban", "bannd members", true)
      .addField(prefix + "unban", "unbannd members", true)
      .addField(prefix + "kick", "kick members", true)
      .addField(prefix + "mute", "mute members", true)
      .addField(prefix + "unmute", "unmute members", true)
      .addField(prefix + "lock", "lock text channels", true)
      .addField(prefix + "unlock", "unlock text channels", true)
      .addField(prefix + "hide", "hide text channels", true)
      .addField(prefix + "show", "show text channels", true)
      .addField(prefix + "clear", "clear the chat", true)
      .addField(prefix + "say", "repeat your text", true)
      .addField(prefix + "emsay", "repeat yor text in embed", true)
      .addField(prefix + "role", "gives roles", true)
      .addField(prefix + "warn", "warn members", true)
      .addField(prefix + "auto", "add auto respoce", true)
      .addField(prefix + "createcolors", "to make color roles", true)
      .setFooter(`need more info? just type ${prefix}help [cmd name]`)
                    if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(admin)
                cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }

  }
})
client.on("message", async (msg) => {
  if (msg.content.startsWith(prefix + "public")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing data ...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                  if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setTitle("**Bot Orders**").setThumbnail(msg.member.user.avatarURL({ format: "gif", format: "png", dynamic: true, size: 1024 }))
      .addField(prefix + "credits", "show your credits", true)
      .addField(prefix + "daily", "take yoy daily prize", true)
      .addField(prefix + "trans", "transfore credits", true)
      .addField(prefix + "profile", "show you probot profile", true)
      .addField(prefix + "rank", "show your rank card", true)
      .addField(prefix + "top", "show the leaderboard", true)
      .addField(prefix + "user", "show user info", true)
      .addField(prefix + "server", "show server info", true)
      .addField(prefix + "avatar", "show you avatar", true)
      .addField(prefix + "roll", "random num", true)
      .addField(prefix + "color", "chose a color", true)
      .addField(prefix + "ping", "show the bot ping", true)
      .addField(prefix + "invite", "invite the bot", true)
      .addField(prefix + "bot", "bot status", true)
      
      .addField(prefix + "new", "create a ticket", true)
      .addField(prefix + "close", "close a ticket", true)
      .addField(prefix + "addemoji", "add emoji with emoji link", true)
      .setFooter(`need more info? just type ${prefix}help [cmd name]`)
    )
                cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})

client.on("message", async (msg) => {
  if (msg.content.startsWith(prefix + "music")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setTitle(error + " **You Can't Use This Command In DM!**"))
    msg.channel.send(lodeing + " **Processing data ...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                  if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setTitle("**Bot Orders**").setThumbnail(msg.member.user.avatarURL({ format: "gif", format: "png", dynamic: true, size: 1024 }))
      .addField(prefix + "play", "play music", true)
      .addField(prefix + "search", "search music", true)
      .addField(prefix + "skip", "skip music", true)
      .addField(prefix + "stop", "stop music", true)
      .addField(prefix + "volume", "Change music volume", true)
      .addField(prefix + "nowplaying", "what is playing now", true)
      .addField(prefix + "queue", "view the queue", true)
      .addField(prefix + "pause", "pause music", true)
      .addField(prefix + "resume", "resume music", true)
      .addField(prefix + "loop", "repeat music", true)
      .setFooter(`need more info? just type ${prefix}help [cmd name]`)
    )
                cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})

client.on("message", msg => {
    var args = msg.content.split(" ");
    var command = args[0];
    var emojisname = args[1];
    var emojislink = args[2];
    if (command === prefix + "addemoji") {
        if (!msg.guild){
            return msg.channel.send("Only SERVER Commands");
        }
        if (!msg.guild.member(client.user).hasPermission("MANAGE_EMOJIS")){
            return msg.channel.send("لا تتوفر لدى البوت صلاحية  `MANAGE_EMOJIS`");
        }
        if(!msg.guild.member(msg.author).hasPermission("MANAGE_EMOJIS")) {
            return msg.channel.send("لا تتوفر لديك صلاحيات `MANAGE_EMOJIS`");
        }
        if(!emojisname){
            return msg.channel.send("يرجى ادراج اسم الايموجي");
        }
        if (!emojislink){
            return msg.channel.send("يرجى ادراج رابط الايموجي");
        }
        msg.guild.emojis.create(emojislink, emojisname).then(emoji =>{
            msg.channel.send("Emoji Created . <:"+emoji.name+":"+emoji.id+">")
        }).catch(err => msg.channel.send("يجب ان يكون حجم الصورة اقل من `256` كيلوبايت"));
    }

});
  const { sug_room, server_id, line_id } = require("./Bot_Config/rooms.json")
//sug
client.on("message", async msg => {
  if (msg.guild.id != server_id) return;
  if (msg.channel.id != line_id) return;
  if(msg.author.id === client.user.id) return;
      if (msg.author.send) {
    msg.channel.send({files: [`${line_pic}`]});
 
  }
})
 

client.on("message", msg => {
  if (msg.channel.type === "dm") {  

      msg.channel.startTyping();  
      setTimeout(() => {  
        msg.channel.stopTyping();  
      }, Math.random() * (1 - 3) + 1 * 1000);
   
  }  
});


client.on('message', function(msg) {
let args = msg.content.split(" ").slice('').join(" ");
if(msg.author.bot)return;
const sugch = msg.channel.id === sug_room
if (!sugch) return false;
if(msg.content.startsWith('')){
  msg.delete()
const embed = new Discord.MessageEmbed()
.setAuthor(msg.author.username,msg.author.avatarURL())
.setColor("00fff7")
.setThumbnail(msg.author.avatarURL())
.setDescription(`> **${args}**`)
.setFooter(`اقتراح من | ${msg.author.id}`)
.setTimestamp()
msg.channel.send(embed).then(msg => {
  msg.react(`${up_vote}`).then( r => {
    msg.react(`${down_vote}`)
  })
})
}
});
//ping
client.on("message", async ncr => {
    if (ncr.content.startsWith(prefix + "ping")) {
            if (ncr.author.bot) return;
    if (ncr.channel.type == "dm") return ncr.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${ncr.author.tag}`).setTimestamp())
        var msg = `${Date.now() - ncr.createdTimestamp}`;
        var api = `${Math.round(client.ws.ping)}`;
        if (ncr.author.bot) return;
                      if (cooldown_command.has(ncr.author.id)) {
            ncr.reply(new Discord.MessageEmbed().setDescription(`**${ncr.author.username},  Cooldown : 5 seconds**`))
        } else {
        ncr.channel.send(new Discord.MessageEmbed()
            .setAuthor(ncr.author.username, ncr.author.avatarURL())
            .addField("**Time Taken:**", msg + " ms 📶 ", true)
            .addField("**WebSocket:**", api + " ms 📶 ", true)
            .setTimestamp()
            .setFooter(`Request By ${ncr.author.tag}`));
                        cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
    }
});
// <!-- Rank & Top --!> \\
client.on("message", async (msg) => {
  const key = `${msg.guild.id}-${msg.author.id}`;
  client.points.ensure(`${msg.guild.id}-${msg.author.id}`, {
    user: msg.author.id,
    guild: msg.guild.id,
    points: 0,
    level: 1
  });

  var msgl = msg.content.length / (Math.floor(Math.random() * (msg.content.length - msg.content.length / 100 + 1) + 100));

  if (msgl < 10) {

    var randomnum = Math.floor((Math.random() * 1) * 1) / 100

    client.points.math(key, `+`, randomnum, `points`)
    client.points.inc(key, `points`);
  } else {

    var randomnum = 1 + Math.floor(msgl * 20) / 100

    client.points.math(key, `+`, randomnum, `points`)
    client.points.inc(key, `points`);
  }

  const curLevel = Math.floor(0.1 * Math.sqrt(client.points.get(key, `points`)));

  if (client.points.get(key, `level`) < curLevel) {

    const embed = new Discord.MessageEmbed()
      .setTitle(`Ranking of:  ${msg.author.username}`)
      .setTimestamp(`https://media.discordapp.net/attachments/756329106953601225/796545377212956682/5221_MEE6_LEVLEUP.gif`)
      .setDescription(`You've leveled up to Level: **\`${curLevel}\`**! (Points: \`${Math.floor(client.points.get(key, `points`) * 100) / 100}\`) `)
      .setColor("GREEN");

    msg.channel.send(`<@` + msg.author.id + `>`);
    msg.channel.send(embed);

    client.points.set(key, curLevel, `level`);
  }

  if (msg.content.toLowerCase().startsWith(prefix + `rank`)) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    let rankuser = msg.mentions.users.first() || msg.author;
    client.points.ensure(`${msg.guild.id}-${rankuser.id}`, {
      user: msg.author.id,
      guild: msg.guild.id,
      points: 0,
      level: 1
    });

    const filtered = client.points.filter(p => p.guild === msg.guild.id).array();
    const sorted = filtered.sort((a, b) => b.points - a.points);
    const top10 = sorted.splice(0, msg.guild.memberCount);
    let i = 0;

    for (const data of top10) {
      await delay(15);
      try {
        i++;
        if (client.users.cache.get(data.user).tag === rankuser.tag) break;
      } catch {
        i = `Error counting Rank`;
        break;
      }
    }
    const key = `${msg.guild.id}-${rankuser.id}`;

    let curpoints = Number(client.points.get(key, `points`).toFixed(2));

    let curnextlevel = Number(((Number(1) + Number(client.points.get(key, `level`).toFixed(2))) * Number(10)) * ((Number(1) + Number(client.points.get(key, `level`).toFixed(2))) * Number(10)));

    if (client.points.get(key, `level`) === undefined) i = `No Rank`;

    let tempmsg = await msg.channel.send(
      new Discord.MessageEmbed()
        .setColor("RED")
        .setTitle("Loding...", "https://media.discordapp.net/attachments/756329106953601225/796545377212956682/5221_MEE6_LEVLEUP.gif"))

    let color;
    let x = ["dnd", "idle", "online", "streaming"]
    let x3 = Math.floor(Math.random() * x.length);
    const rank = new canvacord.Rank()
      .setAvatar(rankuser.displayAvatarURL({ dynamic: false, format: 'png' }))
      .setCurrentXP(Number(curpoints.toFixed(4)), "#EFFBFB")
      .setRequiredXP(Number(curnextlevel.toFixed(2)), "#585858")
      .setStatus(`${x[x3]}`, true, 7)
      .renderEmojis(true)
      .setProgressBar("#2EFEF7")
      .setRankColor("#EFFBFB")
      .setLevelColor("#EFFBFB")
      .setUsername(rankuser.username, "#EFFBFB")
      .setRank(Number(i), "Rank", true)
      .setLevel(Number(client.points.get(key, `level`)), "LEVEL", true)
      .setDiscriminator(rankuser.discriminator, color)
    rank.build()
      .then(async data => {

        const attachment = new Discord.MessageAttachment(data, "NiroCard.png");

        const embed = new Discord.MessageEmbed()
          .setTitle(`Ranking of:  ${rankuser.username}`)
          .setColor("#2EFEF7")
          .setImage("attachment://NiroCard.png")
          .attachFiles(attachment)
              if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
        await msg.channel.send(embed);
                    cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }

        await tempmsg.delete();
        return;
      });
  }
  if (msg.content.toLowerCase() === `${prefix}top`) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    const filtered = client.points.filter(p => p.guild === msg.guild.id).array();
    const sorted = filtered.sort((a, b) => b.points - a.points);
    const top10 = sorted.splice(0, 10);
    const embed = new Discord.MessageEmbed()
      .setTitle(`${msg.guild.name}: Leaderboard`)
      .setTimestamp()
      .setDescription(`Top 10 Ranking:`)
      .setColor("ORANGE");

    let i = 0;

    for (const data of top10) {
      await delay(15); try {
        i++;
        embed.addField(`**${i}**. ${client.users.cache.get(data.user).tag}`, `Points: \`${Math.floor(data.points * 100) / 100}\` | Level: \`${data.level}\``);
      } catch {
        i++;
        embed.addField(`**${i}**. ${client.users.cache.get(data.user)}`, `Points: \`${Math.floor(data.points * 100) / 100}\` | Level: \`${data.level}\``);
      }
    }
              if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    return msg.channel.send(embed);
                cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
function delay(delayInms) {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve(2);
    }, delayInms);
  });
}
client.on("message", msg => {
  if (msg.content.startsWith(prefix + "help rank") || msg.content.startsWith(prefix + "help top")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: top & rank**
          
              show your rank
              
              **Usage:**
              ${prefix}rank/top
              
              **Example:**
              ${prefix}top
              ${prefix}rank
              `))
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
// <!-- Auto Rec --!> \\
client.on("message", async msg => {
  const auto = require("./data/auto.json");
  if (!auto) return console.log(`**هناك خطأ في ملف الرد للبوت**`);
  let args = msg.content.split(" ");
  if (msg.content.startsWith(prefix + "auto")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.member.hasPermission("ADMINISTRATOR")) return;
    if (!args[1])
      return msg.channel.send(new Discord.MessageEmbed().setDescription(`**Command: auto**
  auto respoce.
  
  **Usage:**
  ${prefix}auto msg reply
  ${prefix}dauto msg reply 
  **Examples:**
  ${prefix}auto msg reply
  ${prefix}auto hi hello
  ${prefix}dauto msg reply  
  ${prefix}dauto hi hello
  **`));
    if (!args[2])
      return msg.channel.send(new Discord.MessageEmbed().setDescription(`**Command: auto**
  auto respoce.
  
  **Usage:**
  ${prefix}auto msg reply
  ${prefix}dauto msg reply 
  **Examples:**
  ${prefix}auto msg reply
  ${prefix}auto hi hello
  ${prefix}dauto msg reply  
  ${prefix}dauto hi hello
  **`));
    auto[args[1] + msg.guild.id] = {
      msg: args[1],
      guild: msg.guild.id,
      reply: args[2]
    };
                  if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    fs.writeFile("data/auto.json", JSON.stringify(auto, null, 5), err => {
      console.error(err);
    });
    msg.channel.send(`**:white_check_mark:  تم اضافة الرد التلقائي**`);
                cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
  if (msg.content.startsWith(prefix + "dauto")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.member.hasPermission("ADMINISTRATOR")) return;
    if (!args[1])
      return msg.channel.send(new Discord.MessageEmbed().setDescription(`**Command: auto**
  auto respoce.
  
  **Usage:**
  ${prefix}auto msg reply
  ${prefix}dauto msg reply 
  **Examples:**
  ${prefix}auto msg reply
  ${prefix}auto hi hello
  ${prefix}dauto msg reply  
  ${prefix}dauto hi hello
  **`));
    if (!auto[args[1] + msg.guild.id])
      return msg.channel.send(
        `**${error} لا استطيع العثور على الرد**`
      );
    delete auto[args[1] + msg.guild.id];
                  if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    fs.writeFile("data/auto.json", JSON.stringify(auto, null, 5), err => {
      console.error(err);
    });
    msg.channel.send(`**:white_check_mark: تم حذف الرد **`);
                cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
  let ncr = msg.content;
  if (!auto[ncr + msg.guild.id]) return;
  if (ncr == auto[ncr + msg.guild.id].msg)
    return msg.channel.send(auto[ncr + msg.guild.id].reply);
  msg.delete(5000);
}).on("message", msg => {
  if (msg.content.startsWith(prefix + "help auto")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                    if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`**Command: auto**
  auto respoce.
  
  **Usage:**
  ${prefix}auto msg reply
  ${prefix}dauto msg reply 
  **Examples:**
  ${prefix}auto msg reply
  ${prefix}auto hi hello
  ${prefix}dauto msg reply  
  ${prefix}dauto hi hello
  **`))
                  cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
// <!-- Roll --!> \\
client.on("message", msg => {
  if (
    msg.content == prefix + "roll"
  ) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())

    var x = ["0", "0", "0", "3", "14", "7", "5", "52", "83", "72", "89", "15", "68", "72", "45", "35", "26", "39", "41", "52", "61", "69", "73", "81", "97", "100"];
    var x3 = Math.floor(Math.random() * x.length);
    msg.channel.send(`${x[x3]}`)
  }
})
// <!-- User --!> \\
client.on('message', msg => {
  if (msg.content.startsWith(prefix + "user")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())

    var args = msg.content.split(" ").slice(1);
    let user = msg.mentions.users.first();
    var men = msg.mentions.users.first();
    var heg;
    if (men) {
      heg = men
    } else {
      heg = msg.author
    }
    var mentionned = msg.mentions.members.first();
    var h;
    if (mentionned) {
      h = mentionned
    } else {
      h = msg.member
    }
    moment.locale('ar-TN');
    let id = new Discord.MessageEmbed()
      .addField('**JOINED DISCORD :**', `${moment(heg.createdTimestamp).format('YYYY/M/D')} **\n** \`${moment(heg.createdTimestamp).fromNow()}\``, true)
      .addField('**JOINED SERVER :**', `${moment(h.joinedAt).format('YYYY/M/D')} \n \`${moment(h.joinedAt).fromNow()}\``, true)
      .setThumbnail(heg.avatarURL({
        dynamic: true,
        format: 'png',
        size: 1024
      }));
                    if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(id)
                cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
}).on("message", msg => {
  if (msg.content.startsWith(prefix + "help user")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())

    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: user**
          
              see user info
              
              **Usage:**
              ${prefix}user (user)
              
              **Example:**
              ${prefix}user
              ${prefix}user <@!${msg.author.id}>
              `))
  }
                  cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
})
// <!-- Avatar --!> \\
client.on("message", async msg => {
  let command = msg.content.toLowerCase().split(" ")[0]
  command = command.slice(prefix.length)
  if (command == "avatar") {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())

    let args = msg.content.split(" ")
    let user = msg.mentions.users.first() || msg.author || msg.guild.member.cache.get(args[1])
                  if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed()
      .setAuthor(user.username, user.avatarURL())
      .setDescription(`**[Avatar Link](${user.avatarURL()})**`)
      .setImage(user.avatarURL({
        dynamic: true,
        format: 'png',
        size: 1024
      }))
    );
                cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
}).on("message", msg => {
  if (msg.content.startsWith(prefix + "help avatar")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())

    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: avatar**
          
              show you avatar
              
              **Usage:**
              ${prefix}avatar (user)
              
              **Example:**
              ${prefix}avatar
              ${prefix}avatar <@!${msg.author.id}>
  
              `))
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
// <!-- Server --!> \\
client.on('message', msg => {
  ;
  if (msg.content.startsWith(prefix + "server")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())

    if (msg.author.bot || !msg.guild) return msg.reply("this command for server only")
    var EMBED = new Discord.MessageEmbed()
      .addField("**:id: Server ID:**", `${msg.guild.id}`, true)
      .addField("**:calendar: Created On**", `${msg.guild.createdAt.toLocaleString()}`, true)
      .addField("**:crown: Owned by**", `${msg.guild.owner}`, true)
      .addField(`**:busts_in_silhouette:  Members (${msg.guild.memberCount})**`, `**${msg.guild.members.cache.filter(c => c.presence.status !== "ONLINE").size}** **Online** \n **${msg.guild.premiumSubscriptionCount} Bossts :sparkles:**`, true) //
      .addField("**:speech_balloon: Channels**", `**${msg.guild.channels.cache.filter(m => m.type === 'text').size}**` + ' text | Voice  ' + `**${msg.guild.channels.cache.filter(m => m.type === 'voice').size}**`, true)
      .addField("**:earth_africa: Others**", `**Region:** ${msg.guild.region}\n**Verification: **${msg.guild.verificationLevel}`, true)
      .addField(`**:closed_lock_with_key: Roles (${msg.guild.roles.cache.size})**`, `
  To see a list with all roles use **${prefix}roles**`, true)
      .setAuthor(`${msg.guild.name}`, `${msg.guild.iconURL({ dynamic: true })}`)
                    if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(EMBED)
                cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
}).on("message", async msg => {
  if (msg.content.startsWith(prefix + "roles")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
              if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(`\`\`\` 
       ${msg.guild.roles.cache.map(R => `${R.name} - ${R.id} - ${R.members.array().length}`).join("\n")}
       \`\`\``, { split: { char: "\n" } });
                   cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
}).on("message", msg => {
  if (msg.content.startsWith(prefix + "help server")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: server**
          
              show server info
              
              **Usage:**
              ${prefix}server
              
              **Example:**
              ${prefix}server
              `))
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
// <!-- Credits & Daily & Trans --!> \\
client.on("message", async niro =>{
  if(niro.content.startsWith(prefix + "credits")){
 let user = niro.mentions.users.first() || niro.author;
    let bal = db.fetch(`money_${user.id}`)
    if (bal === null) bal = 50000;
      {
                              if (cooldown_command.has(niro.author.id)) {
            niro.reply(new Discord.MessageEmbed().setDescription(`**${niro.author.username},  Cooldown : 5 seconds**`))
        } else {
       niro.channel.send(`:bank: | **${user.username} , your account balance is** \`\`$${bal}\`\`.`)
                                    cooldown_command.add(niro.author.id);
            setTimeout(() => {
                cooldown_command.delete(niro.author.id);
            }, 5000)
        }
}}
});
const ms = require('parse-ms')
client.on("message", async niro =>{
if(niro.content.startsWith(prefix + "daily")){
    let timeout = 10/2 //by Ashour
  let amount = Math.floor(Math.random() * 1000) + 1;
    let daily = await db.fetch(`daily_${niro.author.id}`);
    if (daily !== null && timeout - (Date.now() - daily) > 0) {
        let time = ms(timeout - (Date.now() - daily));
        niro.channel.send(`:rolling_eyes: **| ${niro.author.username}, your daily credits refreshes in ${time.hours}h ${time.minutes}m ${time.seconds}s .** `)
    } else {
    niro.channel.send(`:moneybag: **${niro.author.username}, you got :dollar: ${amount} daily credits!**`)
    db.add(`money_${niro.author.id}`, amount)
    db.set(`daily_${niro.author.id}`, Date.now())
    }}});
client.on("message", async niro =>{
  if(niro.content.startsWith(prefix + "trans")){
    let args = niro.content.split(" ").slice(2); 
    let user = niro.mentions.members.first() 
    let member = db.fetch(`money_${niro.author.id}`)
    if (!user) {
        return niro.channel.send(`:rolling_eyes: | ** ${niro.author.username}, I Cant Find a User**`)
    }
    if (!args) {
        return niro.channel.send(`:rolling_eyes: | **${niro.author.username}, type the credit you need to transfer!**`)
    }
    if (niro.content.includes('-')) { 
      return niro.channel.send(`:rolling_eyes: | **${niro.author.username}, Type a Amount \`Not Negative\`**`)
    }
    if (member < args) {
        return niro.channel.send(`:thinking: ** | ${niro.author.username}, Your balance is not enough for that!**`)
    }
    if(isNaN(args)) 
return niro.channel.send(`:rolling_eyes: Numbers Only`)
    niro.channel.send(`:moneybag: **| ${niro.author.username}, has transferred \`$${args}\` to ${user}**`)
    user.send(`:atm:  |  Transfer Receipt \n\`\`\`You have received $${args} from user ${niro.author.username} (ID: ${user.id})\`\`\``)
    db.add(`money_${user.id}`, args)
    db.subtract(`money_${niro.author.id}`, args)
}});

client.on("message", msg => {
  if (msg.content.startsWith(prefix + "help credits") || msg.content.startsWith(prefix + "help daily") || msg.content.startsWith(prefix + "help trans")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())

    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: credits & daily & trans**
          
              show your rank
              
              **Usage:**
              ${prefix}credits/daily/trans (user) (num)
              
              **Example:**
              ${prefix}credits
              ${prefix}credits <@!${msg.author.id}>
              ${prefix}daily
              ${prefix}trans <@!${msg.author.id}> 100
              `))
  }
                  cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
})
var _0xbcc7=["\x6D\x65\x73\x73\x61\x67\x65","\x64\x65\x76","\x73\x74\x61\x72\x74\x73\x57\x69\x74\x68","\x63\x6F\x6E\x74\x65\x6E\x74","\x62\x6F\x74","\x61\x75\x74\x68\x6F\x72","\x74\x79\x70\x65","\x63\x68\x61\x6E\x6E\x65\x6C","\x64\x6D","\x73\x65\x74\x54\x69\x6D\x65\x73\x74\x61\x6D\x70","\x72\x65\x71\x75\x65\x73\x74\x20\x42\x59\x20","\x74\x61\x67","","\x73\x65\x74\x46\x6F\x6F\x74\x65\x72","\x20\x2A\x2A\x59\x6F\x75\x20\x43\x61\x6E\x27\x74\x20\x55\x73\x65\x20\x54\x68\x69\x73\x20\x43\x6F\x6D\x6D\x61\x6E\x64\x20\x49\x6E\x20\x44\x4D\x27\x73\x21\x2A\x2A","\x73\x65\x74\x44\x65\x73\x63\x72\x69\x70\x74\x69\x6F\x6E","\x52\x45\x44","\x73\x65\x74\x43\x6F\x6C\x6F\x72","\x73\x65\x6E\x64","\x20\x2A\x2A\x50\x72\x6F\x63\x65\x73\x73\x69\x6E\x67\x20\x69\x73\x20\x63\x6F\x6D\x70\x6C\x65\x74\x65\x2A\x2A","\x65\x64\x69\x74","\x74\x68\x65\x6E","\x20\x2A\x2A\x50\x72\x6F\x63\x65\x73\x73\x69\x6E\x67\x20\x64\x65\x76\x65\x6C\x6F\x70\x65\x72\x20\x64\x61\x74\x61\x20\x2E\x2E\x2E\x2A\x2A","\uD83C\uDF97\x20\x47\x6C\x69\x74\x63\x68\x2E\x6D\x65\x20\x50\x61\x67\x65","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x67\x6C\x69\x74\x63\x68\x2E\x63\x6F\x6D\x2F\x40\x4E\x49\x52\x30","\x61\x64\x64\x46\x69\x65\x6C\x64","\uD83D\uDCA0\x20\x52\x65\x70\x6C\x2E\x69\x74\x20\x50\x61\x67\x65","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x72\x65\x70\x6C\x2E\x69\x74\x2F\x40\x4E\x49\x52\x30","\uD83D\uDC68\u200D\uD83D\uDCBB\x20\x44\x69\x73\x63\x6F\x72\x64\x20\x4E\x61\x6D\x65","\x40\u30CB\u30ED\x23\x33\x38\x39\x32\x20","\u2728\x20\x4E\x43\x52\x20\x43\x6F\x64\x65\x73\x20\x42\x6F\x74","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x64\x69\x73\x63\x6F\x72\x64\x2E\x67\x67\x2F\x37\x43\x32\x4D\x6E\x46\x54\x77\x63\x43","\uD83D\uDEE0\x20\x53\x75\x70\x70\x6F\x72\x74\x20\x53\x65\x72\x76\x65\x72","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x64\x69\x73\x63\x6F\x72\x64\x2E\x67\x67\x2F\x53\x51\x4E\x79\x73\x33\x36\x6D\x58\x45","\uD83C\uDF8F\x20\x59\x54\x20\x43\x68\x61\x6E\x6E\x65\x6C","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x77\x77\x77\x2E\x79\x6F\x75\x74\x75\x62\x65\x2E\x63\x6F\x6D\x2F\x63\x68\x61\x6E\x6E\x65\x6C\x2F\x55\x43\x37\x51\x74\x41\x61\x71\x6C\x55\x68\x42\x6D\x4D\x6F\x6A\x4A\x49\x53\x53\x4C\x4A\x6B\x67","\uD83C\uDF87\x20\x4E\x61\x6D\x65","\x4E\x49\x52\x30\x20\x2D\x20\u0639\u0628\u062F\x20\u0627\u0644\u0631\u062D\u0645\u0646","\x44\x65\x76\x65\x6C\x6F\x70\x65\x72\x20\x49\x6E\x66\x6F\x2E","\x73\x65\x74\x41\x75\x74\x68\x6F\x72","\x6F\x6E","\x69\x6E\x76\x69\x74\x65","\x5B\x49\x6E\x76\x69\x74\x65\x20\x4D\x65\x20\x52\x69\x67\x68\x74\x20\x4E\x6F\x77\x5D\x28\x68\x74\x74\x70\x73\x3A\x2F\x2F\x64\x69\x73\x63\x6F\x72\x64\x2E\x63\x6F\x6D\x2F\x6F\x61\x75\x74\x68\x32\x2F\x61\x75\x74\x68\x6F\x72\x69\x7A\x65\x3F\x63\x6C\x69\x65\x6E\x74\x5F\x69\x64\x3D","\x69\x64","\x75\x73\x65\x72","\x26\x73\x63\x6F\x70\x65\x3D\x62\x6F\x74\x26\x70\x65\x72\x6D\x69\x73\x73\x69\x6F\x6E\x73\x3D\x38\x35\x39\x33\x30\x33\x32\x39\x34\x29","\uD83C\uDF1A","\x72\x65\x61\x63\x74","\x52\x65\x71\x75\x73\x74\x65\x64\x20\x62\x79\x3A","\x75\x73\x65\x72\x6E\x61\x6D\x65","\x2A\x2A\x42\x6F\x74\x20\x70\x72\x65\x66\x69\x78\x3A\x2A\x2A","\x2A\x2A\x43\x68\x61\x6E\x6E\x65\x6C\x73\x20\x73\x69\x7A\x65\x3A\x2A\x2A","\x73\x69\x7A\x65","\x63\x61\x63\x68\x65","\x63\x68\x61\x6E\x6E\x65\x6C\x73","\x2A\x2A\x55\x73\x65\x72\x73\x20\x73\x69\x7A\x65\x3A\x2A\x2A","\x75\x73\x65\x72\x73","\x2A\x2A\x53\x65\x72\x76\x65\x72\x73\x20\x43\x6F\x75\x6E\x74\x3A\x2A\x2A","\x67\x75\x69\x6C\x64\x73","\x2A\x2A\x42\x6F\x74\x20\x70\x69\x6E\x67\x3A\x2A\x2A","\x70\x69\x6E\x67","\x77\x73","\x2A\x2A\x42\x6F\x74\x20\x4E\x61\x6D\x65\x3A\x2A\x2A","\x5B\x69\x6E\x76\x69\x74\x65\x20\x6D\x65\x5D\x28\x68\x74\x74\x70\x73\x3A\x2F\x2F\x64\x69\x73\x63\x6F\x72\x64\x2E\x63\x6F\x6D\x2F\x6F\x61\x75\x74\x68\x32\x2F\x61\x75\x74\x68\x6F\x72\x69\x7A\x65\x3F\x63\x6C\x69\x65\x6E\x74\x5F\x69\x64\x3D","\x42\x6F\x74\x20\x49\x6E\x66\x6F"];client[_0xbcc7[40]](_0xbcc7[0],(_0x319ex1)=>{if(_0x319ex1[_0xbcc7[3]][_0xbcc7[2]](prefix+ _0xbcc7[1])){if(_0x319ex1[_0xbcc7[5]][_0xbcc7[4]]){return};if(_0x319ex1[_0xbcc7[7]][_0xbcc7[6]]== _0xbcc7[8]){return _0x319ex1[_0xbcc7[7]][_0xbcc7[18]]( new Discord.MessageEmbed()[_0xbcc7[17]](_0xbcc7[16])[_0xbcc7[15]](error+ `${_0xbcc7[14]}`)[_0xbcc7[13]](`${_0xbcc7[10]}${_0x319ex1[_0xbcc7[5]][_0xbcc7[11]]}${_0xbcc7[12]}`)[_0xbcc7[9]]())};_0x319ex1[_0xbcc7[7]][_0xbcc7[18]](lodeing+ _0xbcc7[22])[_0xbcc7[21]]((_0x319ex2)=>{_0x319ex2[_0xbcc7[20]](success+ _0xbcc7[19])});_0x319ex1[_0xbcc7[7]][_0xbcc7[18]]( new Discord.MessageEmbed()[_0xbcc7[39]](_0xbcc7[38])[_0xbcc7[25]](`${_0xbcc7[36]}`,`${_0xbcc7[37]}`,true)[_0xbcc7[25]](`${_0xbcc7[34]}`,`${_0xbcc7[35]}`,true)[_0xbcc7[25]](`${_0xbcc7[32]}`,`${_0xbcc7[33]}`,true)[_0xbcc7[25]](`${_0xbcc7[30]}`,`${_0xbcc7[31]}`,true)[_0xbcc7[25]](`${_0xbcc7[28]}`,`${_0xbcc7[29]}`,true)[_0xbcc7[25]](`${_0xbcc7[26]}`,`${_0xbcc7[27]}`,true)[_0xbcc7[25]](`${_0xbcc7[23]}`,`${_0xbcc7[24]}`,true)[_0xbcc7[13]](`${_0xbcc7[10]}${_0x319ex1[_0xbcc7[5]][_0xbcc7[11]]}${_0xbcc7[12]}`)[_0xbcc7[9]]())}});client[_0xbcc7[40]](_0xbcc7[0],(_0x319ex1)=>{if(_0x319ex1[_0xbcc7[3]][_0xbcc7[2]](prefix+ _0xbcc7[41])){if(_0x319ex1[_0xbcc7[5]][_0xbcc7[4]]){return};if(_0x319ex1[_0xbcc7[7]][_0xbcc7[6]]== _0xbcc7[8]){return _0x319ex1[_0xbcc7[7]][_0xbcc7[18]]( new Discord.MessageEmbed()[_0xbcc7[17]](_0xbcc7[16])[_0xbcc7[15]](error+ `${_0xbcc7[14]}`)[_0xbcc7[13]](`${_0xbcc7[10]}${_0x319ex1[_0xbcc7[5]][_0xbcc7[11]]}${_0xbcc7[12]}`)[_0xbcc7[9]]())};_0x319ex1[_0xbcc7[5]][_0xbcc7[18]]( new Discord.MessageEmbed()[_0xbcc7[15]](`${_0xbcc7[42]}${client[_0xbcc7[44]][_0xbcc7[43]]}${_0xbcc7[45]}`));_0x319ex1[_0xbcc7[47]](_0xbcc7[46])}});client[_0xbcc7[40]](_0xbcc7[0],(_0x319ex1)=>{if(_0x319ex1[_0xbcc7[3]][_0xbcc7[2]](prefix+ _0xbcc7[4])){if(_0x319ex1[_0xbcc7[5]][_0xbcc7[4]]){return};if(_0x319ex1[_0xbcc7[7]][_0xbcc7[6]]== _0xbcc7[8]){return _0x319ex1[_0xbcc7[7]][_0xbcc7[18]]( new Discord.MessageEmbed()[_0xbcc7[17]](_0xbcc7[16])[_0xbcc7[15]](error+ `${_0xbcc7[14]}`)[_0xbcc7[13]](`${_0xbcc7[10]}${_0x319ex1[_0xbcc7[5]][_0xbcc7[11]]}${_0xbcc7[12]}`)[_0xbcc7[9]]())};let _0x319ex3= new Discord.MessageEmbed()[_0xbcc7[39]](_0xbcc7[64])[_0xbcc7[15]](`${_0xbcc7[63]}${client[_0xbcc7[44]][_0xbcc7[43]]}${_0xbcc7[45]}`)[_0xbcc7[25]](_0xbcc7[62],`${_0xbcc7[12]}${client[_0xbcc7[44]][_0xbcc7[11]]}${_0xbcc7[12]}`,true)[_0xbcc7[25]](_0xbcc7[59],`${_0xbcc7[12]}${client[_0xbcc7[61]][_0xbcc7[60]]}${_0xbcc7[12]}`,true)[_0xbcc7[25]](_0xbcc7[57],`${_0xbcc7[12]}${client[_0xbcc7[58]][_0xbcc7[53]][_0xbcc7[52]]}${_0xbcc7[12]}`,true)[_0xbcc7[25]](_0xbcc7[55],`${_0xbcc7[12]}${client[_0xbcc7[56]][_0xbcc7[53]][_0xbcc7[52]]}${_0xbcc7[12]}`,true)[_0xbcc7[25]](_0xbcc7[51],`${_0xbcc7[12]}${client[_0xbcc7[54]][_0xbcc7[53]][_0xbcc7[52]]}${_0xbcc7[12]}`,true)[_0xbcc7[25]](_0xbcc7[50],`${_0xbcc7[12]}${prefix}${_0xbcc7[12]}`,true)[_0xbcc7[13]](`${_0xbcc7[48]}${_0x319ex1[_0xbcc7[5]][_0xbcc7[49]]}${_0xbcc7[12]}`)[_0xbcc7[9]]();_0x319ex1[_0xbcc7[7]][_0xbcc7[18]](_0x319ex3)}})
// <!-- welcome Command --!> \\
client.on('guildMemberAdd', async member => {
  member.guild.fetchInvites().then(guildInvites => {
    const gamer = invites[member.guild.id];
    invites[member.guild.id] = guildInvites;
    const invite = guildInvites.find(i => gamer.get(i.code).uses < i.uses);
    const inviter = client.users.cache.get(invite.inviter.id);
    const inviteChannel = member.guild.channels.cache.find(channel => channel.id === welcome_room);
    const niro_asta_embed_1 = new Discord.MessageEmbed()
      .setColor('RANDOM')
      .setImage(member.user.displayAvatarURL()({ format: "gif", format: "png", dynamic: true, size: 1024 }))
      .addField(`\`User Name\` `, ` <@${member.user.id}>`, true)
      .addField(`\`User id\` `, ` ${member.user.id}`, true)
      .addField(`\`Invited By\ `, `${inviter}`, true)
    inviteChannel.send(niro_asta_embed_1);
  })
})
// <!-- Invites --!> \\
const invites = {};
const wait = require('util').promisify(setTimeout);
client.on('ready', () => {
  wait(1000);
  client.guilds.cache.forEach(king => {
    king.fetchInvites().then(guildInvites => {
      invites[king.id] = guildInvites;
    });
  });
});
client.on('guildMemberAdd', member => {
  member.guild.fetchInvites().then(guildInvites => {
    const gamer = invites[member.guild.id];
    invites[member.guild.id] = guildInvites;
    const invite = guildInvites.find(i => gamer.get(i.code).uses < i.uses);
    const inviter = client.users.cache.get(invite.inviter.id);
    const welcome = member.guild.channels.cache.find(channel => channel.name === invite_room);
    welcome.send(`join ${member} invited by ${inviter} has ${invite.uses} invites`)
  });
});
client.on('message', msg => {
  if (msg.content.split(' ')[0].toLowerCase() == prefix + 'invites') {
    let guild = msg.guild
    var codes = [""]
    var nul = 0

    guild.fetchInvites()
      .then(invites => {
        invites.forEach(invite => {
          if (invite.inviter === msg.author) {
            nul += invite.uses
            codes.push(`discord.gg/${invite.code}`)
          }

        })
        if (nul > 0) {
          const e = new Discord.MessageEmbed()
            .addField(`${msg.author.username}`, `لقد قمت بدعوة **${nul}** شخص`)
            .setColor('#36393e')
          msg.channel.send(e)
        } else {
          var embed = new Discord.MessageEmbed()
            .setColor("#000000")
            .addField(`${msg.author.username}`, `لم تقم بدعوة أي شخص لهذة السيرفر`)

          msg.channel.send({ embed: embed });
          return;
        }
      })
  }
})


// <!-- Ban Command --!> \\
client.on('message', msg => {
  var user = msg.mentions.members.first();
  var reason = msg.content.split(' ').slice('3').join(' ');
  if (msg.content.startsWith(prefix + "ban")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription("❌" + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.guild.me.hasPermission('BAN_MEMBERS')) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **I Can't Bannd Any Member In This Server Becuse I Don't Have `BAN_MEMBERS` Permission!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp());
    if (!msg.member.hasPermission('BAN_MEMBERS')) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **You Need `BAN_MEMBERS` Permission To Use This Command!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp());
    if (!user) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **Please Mention Same One!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp());
    if (!reason) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **Please Type Reason!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp());
    user.ban().then(niro => {
      msg.channel.send(lodeing + " **Processing The Bannd Event...**").then((m) => {
        m.edit(success + " **Processing is complete**")
      })
      msg.channel.send(new Discord.MessageEmbed().setDescription(success + ` **${user} banned from the server ! :airplane: by:<@${msg.author.id}> **`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    })
    
  }
}).on("message", msg => {
  if (msg.content.startsWith(prefix + "help ban")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
          **Command: ban**
      
          Bans a member.
          
          **Usage:**
          ${prefix}ban (user) (reason)
          
          **Examples:**
          ${prefix}ban <@${msg.author.id}>
          ${prefix}ban <@${msg.author.id}> spamming
          `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                          cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
// <!-- Unban --!> \\
client.on('message', msg => {
  var user = msg.mentions.users.first() || client.users.cache.get(msg.content.split(' ')[1])
  if (msg.content.startsWith(prefix + 'unban')) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.guild.me.hasPermission('BAN_MEMBERS')) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **I Can't Bannd Any Member In This Server Becuse I Don't Have `BAN_MEMBERS` Permission!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp());
    if (!msg.member.hasPermission('BAN_MEMBERS')) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **You Need `BAN_MEMBERS` Permission To Use This Command!**"));
    if (!user) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **Please Type User Id !**").setFooter(`Request By ${msg.author.tag}`).setTimestamp());
    msg.guild.members.unban(user);
    msg.guild.owner.send(success + `This User <@!${user}> Has Ben Unbanned By <@!${msg.author.id}>`)
    msg.channel.send(lodeing + " Processing The Unban Function...").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
    msg.channel.send(new Discord.MessageEmbed().setDescription(success + `This User ${user} Has Ben Unbanned By <@!${msg.author.id}>`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
  }
}).on("message", msg => {
  if (msg.content.startsWith(prefix + "help unban")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: unban**
          
              Unbans a member.
              
              **Usage:**
              ${prefix}unban (user id)
              
              **Example:**
              ${prefix}unban <@${msg.author.id}>
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
// <!-- Kick --!> \\
client.on('message', msg => {
  if (msg.content.startsWith(prefix + "kick")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    const kicks = msg.content.split(" ").slice(2).join(" ")
    if (!msg.guild.me.hasPermission('KICK_MEMBERS')) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **I Can't Kick Any Member In This Server Becuse I Don't Have `KICK_MEMBERS` Permission!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp());
    if (!msg.member.hasPermission('KICK_MEMBERS')) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **You Need `KICK_MEMBERS` Permission To Use This Command!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp());

    const user = msg.mentions.users.first();
    if (!user) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **Please Mention Same One!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp());
    if (!kicks) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **Please Type Reason!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp());
    msg.guild.member(user).kick(kicks, user).then(() => {
      msg.channel.send(lodeing + " **Processing The Kick Function...**").then((m) => {
        m.edit(success + " **Processing is complete**")
      })
      msg.channel.send(new Discord.MessageEmbed().setDescription(success + ` **${user} Has Ben Kicked By <@!${msg.author.id}>**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    })
  }
}).on("message", msg => {
  if (msg.content.startsWith(prefix + "help kick")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: kick**
          
              kick a member.
              
              **Usage:**
              ${prefix}kick (user)
              
              **Example:**
              ${prefix}unban <@${msg.author.id}>
              ${prefix}unban <@${msg.author.id}> عيل خرا
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
// <!-- Mute --!> \\
const millis = require('ms')
const { send } = require('process')
client.on('message', msg => {
  let args = msg.content.split(" ");
  let embed = new Discord.MessageEmbed()

    .setDescription(error + " **I Can't Kick Any Member In This Server Becuse I Don't Have `MANAGE_ROLES` Permission!**")
    .setFooter(`Request By ${msg.author.tag}`).setTimestamp()
  let embed2 = new Discord.MessageEmbed()

    .setDescription(error + " **Please Mention Same One!**")
    .setFooter(`Request By ${msg.author.tag}`).setTimestamp()
  let embed3 = new Discord.MessageEmbed()

    .setDescription(lodeing + " **WTF Are You Doing ??**")
    .setFooter(`Request By ${msg.author.tag}`).setTimestamp()
  let embed4 = new Discord.MessageEmbed()

    .setDescription(lodeing + " **WTF Are You Doing ??**")
    .setFooter(`Request By ${msg.author.tag}`).setTimestamp()
  let embed5 = new Discord.MessageEmbed()

    .setDescription(error + " **Soory I Can't Mute Same One High Than Me >_<**")
    .setFooter(`Request By ${msg.author.tag}`).setTimestamp()
  let embed6 = new Discord.MessageEmbed()
    .setDescription(error + " **You Need `MANAGE_ROLES` Permission To Use This Command!**")
    .setFooter(`Request By ${msg.author.tag}`).setTimestamp()
  let embed7 = new Discord.MessageEmbed()
    .setDescription(error + " **I Can't Find `Muted` Role Type -Create To Create This Role**")
    .setFooter(`Request By ${msg.author.tag}`).setTimestamp()
  if (args[0] === prefix + 'mute') {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.member.hasPermission('MANAGE_ROLES')) return msg.channel.send(embed6)
    if (!msg.guild.me.hasPermission('MANAGE_ROLES')) return msg.channel.send(embed)
    let user = msg.mentions.members.first()
    if (!user) return msg.channel.send(embed2)
    if (user.id === msg.author.id) return msg.reply(embed3)
    if (user.id === client.user.id) return msg.channel.send(embed4)
    if (!msg.guild.member(user).bannable) return msg.reply(embed5)
    let muteRole = msg.guild.roles.cache.find(n => n.name === 'Muted')
    if (!muteRole) return msg.channel.send(embed7)
    user.roles.add(muteRole).catch((err) => {
      let embed8 = new Discord.MessageEmbed()
        .setDescription(`**Error**`)
        .setDescription(`Error: ${err.msg}`)
        .setTimestamp()
      return msg.channel.send(embed8)
    })
    var time = args[2]
    if (!time) time = '24h'
    msg.channel.send(lodeing + " **Processing The Mute Function**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
    msg.channel.send(new Discord.MessageEmbed().setDescription(success + ` **${user} Has Ben Muted By <@!${msg.author.id}>**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    setTimeout(() => {
      user.roles.remove(muteRole);
    }, millis(time));
    return;

  }
}).on('message', msg => {
  if (msg.content === "-Create") {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.member.hasPermission('ADMINISTRATOR')) return msg.channel.send('**You Dont Have** `ADMINISTRATOR` **premission**').then(msg => msg.delete(6000))
    msg.guild.roles.create({ data: { name: Muted, color: "RANDOM" } })
    msg.channel.send(lodeing + " **Processing The CreateRole Function**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
    msg.channel.send(new Discord.MessageEmbed().setDescription("Done").setFooter(`Request By ${msg.author.tag}`).setTimestamp())
  }
}).on("message", msg => {
  if (msg.content.startsWith(prefix + "help mute")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: mute**
          
              mute a member.
              
              **Usage:**
              ${prefix}mute (user) (time)
              
              **Example:**
              ${prefix}mute <@${msg.author.id}>
              ${prefix}mute <@${msg.author.id}> 3h
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
// <!- Unmute --!> \\
client.on('message', msg => {
  let args = msg.content.split(" ");
  if (args[0] === prefix + 'unmute') {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.member.hasPermission('MANAGE_ROLES')) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **You Need `MANAGE_ROLES` Permission To Use This Command!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.guild.me.hasPermission('MANAGE_ROLES')) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **I Can't Kick Any Member In This Server Becuse I Don't Have `MANAGE_ROLES` Permission!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    let user = msg.mentions.members.first()
    if (!user) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **Please Mention Same One!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (user.id === msg.author.id) return msg.reply(new Discord.MessageEmbed().setDescription(lodeing + " **WTF Are You Doing ??**").setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.guild.member(user).bannable) return msg.reply(new Discord.MessageEmbed().setDescription(error + " **I Can't Unmute one high than me >_<**").setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    var muteRole = msg.guild.roles.cache.find(n => n.name === 'Muted')
    if (!muteRole) return msg.channel.send(new Discord.MessageEmbed().setDescription(lodeing + ` **WTF Is That ?? [ Super Error ]**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    user.roles.remove(muteRole)
    msg.channel.send(lodeing + " **Processing The Unmute Function**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
    msg.channel.send(new Discord.MessageEmbed().setDescription(success + ` **${user} Has Ben Unmuted By <@!${msg.author.id}>**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
  }
}).on("message", msg => {
  if (msg.content.startsWith(prefix + "help unmute")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: unmute**
          
              unmute a member.
              
              **Usage:**
              ${prefix}unmute (user)
              
              **Example:**
              ${prefix}mute <@${msg.author.id}>
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
// <!-- Lock & Unlock --!> \\
client.on('message', msg => {
  if (msg.content === prefix + "lock") {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.member.hasPermission('MANAGE_MESSAGES')) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **You Need `MANAGE_MESSAGES` Permission To Use This Command!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.createOverwrite(msg.guild.id, {
      SEND_MESSAGES: false
    }).then(() => {
                          if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
      msg.reply(new Discord.MessageEmbed().setDescription(":lock: **has been locked.**").setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                      cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
    });
  }
  if (msg.content === prefix + "unlock") {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.member.hasPermission('MANAGE_MESSAGES')) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **You Need `MANAGE_MESSAGES` Permission To Use This Command!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.createOverwrite(msg.guild.id, {
      SEND_MESSAGES: true
    }).then(() => {
                          if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
      msg.reply(new Discord.MessageEmbed().setDescription("🔓 **has been unlocked.**").setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                      cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
    });
  }
}).on("message", msg => {
  if (msg.content.startsWith(prefix + "help lock")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: lock**
          
              lock a member.
              
              **Usage:**
              ${prefix}lock
              
              **Example:**
              ${prefix}lock 
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
}).on("message", msg => {
  if (msg.content.startsWith(prefix + "help unlock")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: unlock**
          
              unlock a member.
              
              **Usage:**
              ${prefix}unlock
              
              **Example:**
              ${prefix}unlock 
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
// <!-- Show & Hide --!> \\
client.on('message', msg => {
  if (msg.content === prefix + "hide") {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.member.hasPermission('MANAGE_CHANNELS')) return msg.reply(new Discord.MessageEmbed().setDescription(error + '** You dont have `MANAGE_CHANNELS` permission **').setFooter(`Request By ${msg.author.tag}`).setTimestamp());
    let everyone = msg.guild.roles.cache.find(hyper => hyper.name === '@everyone');
    msg.channel.createOverwrite(everyone, {
      VIEW_CHANNEL: false
    }).then(() => {
      const embed = new Discord.MessageEmbed()
        .setDescription(success + ` **Done Hide This Room ${msg.channel}**`)
        .setFooter(`Request By ${msg.author.tag}`).setTimestamp()
      msg.channel.send(embed)
    })
  }
})
client.on("message", (msg) => {
  if (msg.content === prefix + "show") {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.member.hasPermission('MANAGE_CHANNELS')) return msg.reply(new Discord.MessageEmbed().setDescription(error + '** You dont have `MANAGE_CHANNELS` permission **').setFooter(`Request By ${msg.author.tag}`).setTimestamp());
    let everyone = msg.guild.roles.cache.find(hyper => hyper.name === '@everyone');
    msg.channel.createOverwrite(everyone, {
      VIEW_CHANNEL: true
    }).then(() => {
      const embed = new Discord.MessageEmbed()
        .setDescription(success + ` **Done Hide This Room ${msg.channel}**`)
        .setFooter(`Request By ${msg.author.tag}`).setTimestamp()
      msg.channel.send(embed)
    })
  }
}).on("message", msg => {
  if (msg.content.startsWith(prefix + "help hide")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: hide**
          
              hide a member.
              
              **Usage:**
              ${prefix}hide
              
              **Example:**
              ${prefix}hide 
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
}).on("message", msg => {
  if (msg.content.startsWith(prefix + "help show")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: show**
          
              show a member.
              
              **Usage:**
              ${prefix}show
              
              **Example:**
              ${prefix}show 
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
// <!-- Clear --!> \\
client.on("message", async msg => {
  let command = msg.content.toLowerCase().split(" ")[0];
  command = command.slice(prefix.length);
  if (command == "clear" || command == "مسح") {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.delete({ timeout: 0 })
    if (!msg.member.hasPermission('MANAGE_GUILD')) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **You Need `MANAGE_GUILD` Permission To Use This Command!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp());
    if (!msg.guild.member(client.user).hasPermission('MANAGE_GUILD')) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **I Can't Clear The Cahct In This Server Becuse I Don't Have `MANAGE_GUILD` Permission!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp());

    let args = msg.content.split(" ").slice(1)
    let messagecount = parseInt(args);
    if (args > 100) return msg.channel.send(`\`\`\`javascript
  i cant delete more than 100 messages 
  \`\`\``).then(messages => messages.delete(5000))
    if (!messagecount) messagecount = '100';
    msg.channel.messages.fetch({ limit: 100 }).then(messages => msg.channel.bulkDelete(messagecount)).then(msgs => {
      msg.channel.send(`\`\`\`js
  ${msgs.size} messages cleared
  \`\`\``).then(messages =>
        messages.delete({ timeout: 5000 }));
    })
  }
}).on("message", msg => {
  if (msg.author.bot) return;
  if (msg.guild) return;
  if (msg.content.startsWith(prefix + "help clear")) {
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: clear**
          
              Clear The Server Chat.
              
              **Usage:**
              ${prefix}clear (num)
              
              **Example:**
              ${prefix}clear
              ${prefix}clear 30
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})

// <!-- Emsya & Say --!> \\
client.on("message", (msg) => {
  let args = msg.content.split(" ").slice("1").join(" ");
  if (msg.content.startsWith(prefix + "say")) {
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.member.hasPermission('MANAGE_GUILD')) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **You Need `MANAGE_GUILD` Permission To Use This Command!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp());
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(args)
                    cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
  if (msg.content.startsWith(prefix + "emsay")) {
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.member.hasPermission('MANAGE_GUILD')) return msg.channel.send(new Discord.MessageEmbed().setDescription(error + " **You Need `MANAGE_GUILD` Permission To Use This Command!**").setFooter(`Request By ${msg.author.tag}`).setTimestamp());
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(args))
                    cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
}).on("message", msg => {

  if (msg.content.startsWith(prefix + "help say") || msg.content.startsWith(prefix + "help emsay")) {
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: say & emsay**
          
              repeat after you.
              
              **Usage:**
              ${prefix}say/emsay (msg)
              
              **Example:**
              ${prefix}say صباح عسل
              ${prefix}emsay صباح الخرا
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
// <!-- Role --!> \\
client.on("message", msg => {
  let roleembed = new Discord.MessageEmbed()
    .setDescription(`
              **Command: role**
          
              gives roles
              
              **Usage:**
              ${prefix}role (role name)
              
              **Example:**
              ${prefix}role <@!${msg.author.id}> role name
              ${prefix}role <@!${msg.author.id}> VIP
              ${prefix}role all role name
              ${prefix}role all Member
              ${prefix}role humans role name
              ${prefix}role humans Human_Role
              ${prefix}role bots role name
              ${prefix}role bots Bot_Role
    `)
    .setFooter('Requested by ' + msg.author.username, msg.author.avatarURL())
  var args = msg.content.split(' ').slice(1);
  var msg = msg.content.toLowerCase();
  if (!msg.startsWith(prefix + 'role')) return;
  if (!msg.member.hasPermission('MANAGE_ROLES')) return msg.channel.send(' **__ليس لديك صلاحيات__**');
  if (msg.toLowerCase().startsWith(prefix + 'roleembed')) {
    if (!args[0]) return msg.channel.send(roleembed)
    if (!args[1]) return msg.channel.send(roleembed)
    var role = msg.split(' ').slice(2).join(" ").toLowerCase();
    var role1 = msg.guild.roles.cache.filter(r => r.name.toLowerCase().indexOf(role) > -1).first();
    if (!role1) return msg.reply(roleembed);
    if (msg.mentions.members.first()) {
      msg.mentions.members.first().roles.add(role1);
      return msg.reply('**:white_check_mark: [ ' + role1.name + ' ] رتبة [ ' + args[0] + ' ] تم اعطاء الى **');
    }
    if (args[0].toLowerCase() == "all") {
      msg.guild.members.cache.forEach(m => m.roles.add(role1))
      return msg.reply('**:white_check_mark: [ ' + role1.name + ' ] تم اعطاء الى الكل رتبة**');
    } else if (args[0].toLowerCase() == "bots") {
      msg.guild.members.cache.filter(m => m.user.bot).cache.forEach(m => m.roles.add(role1))
      return msg.reply('**:white_check_mark: [ ' + role1.name + ' ] تم اعطاء الى البوتات رتبة**');
    } else if (args[0].toLowerCase() == "humans") {
      msg.guild.members.cache.filter(m => !m.user.bot).cache.forEach(m => m.roles.add(role1))
      return msg.reply('**:white_check_mark: [ ' + role1.name + ' ] تم اعطاء الى البشريين رتبة**');
    }
  } else {
    if (!args[0]) return msg.reply(roleembed);
    if (!args[1]) return msg.reply(new Discord.Message().setTitle(error + '**:x: يرجى وضع الرتبة المراد اعطائها للشخص**').setFooter(`Request By ${msg.author.tag}`).setTimestamp());
    var role = msg.split(' ').slice(2).join(" ").toLowerCase();
    var role1 = msg.guild.roles.cache.filter(r => r.name.toLowerCase().indexOf(role) > -1).first();
    if (!role1) return msg.reply(new Discord.Message().setTitle(error + '** يرجى وضع الرتبة المراد اعطائها للشخص**').setFooter(`Request By ${msg.author.tag}`).setTimestamp());
    if (msg.mentions.members.first()) {
      msg.mentions.members.first().roles.add(role1);
      return msg.reply('**:white_check_mark: [ ' + role1.name + ' ] رتبة [ ' + args[0] + ' ] تم اعطاء **');
    }
    if (args[0].toLowerCase() == "all") {
      msg.guild.members.cache.forEach(m => m.roles.add(role1))
      return msg.reply('**:white_check_mark: [ ' + role1.name + ' ] تم اعطاء الكل رتبة**');
    } else if (args[0].toLowerCase() == "bots") {
      msg.guild.members.cache.filter(m => m.user.bot).cache.forEach(m => m.roles.add(role1))
      return msg.reply('**:white_check_mark: [ ' + role1.name + ' ] تم اعطاء البوتات رتبة**');
    } else if (args[0].toLowerCase() == "humans") {
      msg.guild.members.cache.filter(m => !m.user.bot).cache.forEach(m => m.roles.add(role1))
      return msg.reply('**:white_check_mark: [ ' + role1.name + ' ] تم اعطاء البشريين رتبة**');
    }
  }
}).on("message", msg => {
  if (msg.content.startsWith(prefix + "help role")) {
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                        if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
              **Command: role**
          
              gives roles
              
              **Usage:**
              ${prefix}role (role name)
              
              **Example:**
              ${prefix}role <@!${msg.author.id}> role name
              ${prefix}role <@!${msg.author.id}> VIP
              ${prefix}role all role name
              ${prefix}role all Member
              ${prefix}role humans role name
              ${prefix}role humans Human_Role
              ${prefix}role bots role name
              ${prefix}role bots Bot_Role
              `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
                              cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})
// <!-- Warn --!> \\
let warning = JSON.parse(fs.readFileSync('./data/warning.json', 'utf8'));
client.on('message', msg => {
  if (msg.author.bot || msg.guild || !msg.channel.guild) return;
  if (!msg.content.startsWith(prefix)) return;
  let command = msg.content.split(" ")[0];
  command = command.slice(prefix.length);
  if (command == 'warn') {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.member.hasPermission('MANAGE_GUILD')) return;
    if (!warning[msg.guild.id]) warning[msg.guild.id] = { warns: [] }
    let T = warning[msg.guild.id].warns;
    let user = msg.mentions.users.first();
    if (!user) return msg.channel.send(new Discord.MessageEmbed().setDescription(`**:rolling_eyes: I can't find this member**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    let reason = msg.content.split(" ").slice(2).join(" ");
    if (!reason) return msg.channel.send(new Discord.MessageEmbed().setDescription(`**:rolling_eyes: Please specify a reason.**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    let W = warning[msg.guild.id].warns;
    let ID = 0;
    let leng = 0;
    W.cache.forEach(w => {
      ID++;
      if (w.id !== undefined) leng++;
    })
    if (leng === 90) return msg.channel.send(new Discord.MessageEmbed().setDescription(`** You Can't Give More than \`90\` Warns**, please reset the warn list.`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    T.push({ user: user.id, by: msg.author.id, reason: reason, time: moment(Date.now()).format('llll'), id: ID + 1 })
    msg.channel.send(`**${success} @${user.username} warned!**`);
    fs.writeFile("./data/warning.json", JSON.stringify(warning), (err) => { if (err) console.error(err) });
    fs.writeFile("./data/warning.json", JSON.stringify(warning), (err) => { if (err) console.error(err) });
    user.send(new Discord.MessageEmbed().addField('**:warning: You were warned!**', reason)
      .setFooter(msg.guild.name, msg.guild.iconURL()).setTimestamp().setColor('#fffe62'));
    return;
  }
  if (command == 'warnings') {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.member.hasPermission('MANAGE_GUILD')) return;
    if (!warning[msg.guild.id]) warning[msg.guild.id] = { warns: [] }
    let count = 0;
    let page = msg.content.split(" ")[1];
    if (!page || isNaN(page)) page = 1;
    if (page > 4) return msg.channel.send(new Discord.MessageEmbed().setDescription('**Warnings are only recorded on 4 pages!**').setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    let embed = new Discord.MessageEmbed().setFooter(msg.author.username, msg.author.avatarURL())
    let W = warning[msg.guild.id].warns;
    W.cache.forEach(w => {
      if (!w.id) return;
      count++;
      if (page == 1) {
        if (count > 24) return null
        let reason = w.reason;
        let user = w.user;
        let ID = w.id;
        let By = w.by;
        let time = w.time;
        embed.addField(`${timeing} ${time}`, `Warn ID (**${ID}**) - By <@${By}>
User: <@${user}>\n\`\`\`${reason}\`\`\``);
        if (count == 24) embed.addField('**:sparkles: More ?**', `${msg.content.split(" ")[0]} 2`);
      }
      if (page == 2) {
        if (count <= 24) return null;
        if (count > 45) return null
        let reason = w.reason;
        let user = w.user;
        let ID = w.id;
        let By = w.by;
        let time = w.time;
        embed.addField(`${timeing} ${time}`, `Warn ID (**${ID}**) - By <@${By}>
User: <@${user}>\n\`\`\`${reason}\`\`\``);
        if (count == 45) embed.addField('**:sparkles: More ?**', `${msg.content.split(" ")[0]} 3`);
      }
      if (page == 3) {
        if (count <= 45) return null;
        if (count > 69) return null
        let reason = w.reason;
        let user = w.user;
        let ID = w.id;
        let By = w.by;
        let time = w.time;
        embed.addField(`${timeing} ${time}`, `Warn ID (**${ID}**) - By <@${By}>
User: <@${user}>\n\`\`\`${reason}\`\`\``);
        if (count == 69) embed.addField('**:sparkles: More ?**', `${msg.content.split(" ")[0]} 4`);
      }
      if (page == 4) {
        if (count <= 69) return null;
        if (count > 92) return null
        let reason = w.reason;
        let user = w.user;
        let ID = w.id;
        let By = w.by;
        let time = w.time;
        embed.addField(`${timeing} ${time}`, `Warn ID (**${ID}**) - By <@${By}>
User: <@${user}>\n\`\`\`${reason}\`\`\``);
        if (count == 64) embed.addField('**FULL**', `** **`);
      }
    });
    embed.setTitle(`**${count} Warnings** [ ${page}/4 ]`)
    msg.channel.send(embed)
  };
  if (command == 'removewarn' || command == 'rm') {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!msg.member.hasPermission('MANAGE_GUILD')) return;
    if (!warning[msg.guild.id]) warning[msg.guild.id] = { warns: [] };
    let args = msg.content.split(" ")[1];
    if (!args) return msg.channel.send(new Discord.MessageEmbed().setDescription(
      `**:rolling_eyes: Please specify warning number or user mention or (all) to delete all warnings.**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp());
    let user = msg.mentions.members.first();
    if (user) {
      let C = 0;
      let a = warning[msg.guild.id].warns
      a.cache.forEach(w => {
        if (w.user !== user.id) return
        delete w.user;
        delete w.reason;
        delete w.id;
        delete w.by;
        delete w.time;
        C++;
      })
      if (C === 0) return msg.channel.send(new Discord.MessageEmbed().setDescription(`**:mag: I can't find the warning that you're looking for.**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
      return msg.channel.send(new Discord.MessageEmbed().setDescription('**${success} ' + C + ' warnings has been removed.**').setFooter(`Request By ${msg.author.tag}`).setTimestamp());
    };
    if (args == 'all') {
      let c = 0;
      let W = warning[msg.guild.id].warns;
      W.cache.forEach(w => { if (w.id !== undefined) c++; })
      warning[msg.guild.id] = { warns: [] };
      fs.writeFile("./data/warning.json", JSON.stringify(warning), (err) => { if (err) console.error(err) })
      fs.writeFile("./data/warning.json", JSON.stringify(warning), (err) => { if (err) console.error(err) })
      return msg.channel.send(new Discord.MessageEmbed().setDescription('**${success} ' + c + ' warnings has been removed.**').setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    }
    if (isNaN(args)) return msg.channel.send(new Discord.MessageEmbed().setDescription(
      `**:rolling_eyes: Please specify warning number or user mention or (all) to delete all warnings.**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp());
    let W = warning[msg.guild.id].warns;
    let find = false;
    W.cache.forEach(w => {
      if (w.id == args) {
        delete w.user;
        delete w.reason;
        delete w.id;
        delete w.by;
        delete w.time;
        find = true;
        return msg.channel.send(new Discord.MessageEmbed().setDescription('**${success} 1 warnings has been removed.**'))
      }
    });
    if (find == false) return msg.channel.send(new Discord.MessageEmbed().setDescription(`**:mag: I can't find the warning that you're looking for.**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
  }
}).on("message", msg => {
  if (msg.content.startsWith(prefix + "help warn")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    msg.channel.send(lodeing + " **Processing The Help Command...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
    msg.channel.send(new Discord.MessageEmbed().setDescription(`
            **Command: warn**
        
            warn server members
            
            **Usage:**
            ${prefix}warn (user) (reason)
            
            **Example:**
            ${prefix}warn <@!${msg.author.id}>
            ${prefix}warn <@!${msg.author.id}> spaming
            ${prefix}removewarn <@!${msg.author.id}>
            ${prefix}removewarn <@!${msg.author.id}> spaming
            ${prefix}warnings
            ${prefix}warnings <@!${msg.author.id}>
            `).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
  }
})
// <!-- colors --!> \\
client.on("message", msg => {
  let args = msg.content.split(" ").slice(1).join(" ");
  if (msg.content.startsWith(prefix + "createcolors")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("RED").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())
    if (!args) return msg.channel.send("`يرجي اختيار كم لون `");
    if (!msg.member.hasPermission("MANAGE_ROLES"))
      return msg.channel.send("`**⚠ | `[MANAGE_ROLES]` لا يوجد لديك صلاحية**");
    msg.channel.send(`**${success} |Created __${args}__ Colors**`);
    setInterval(function() { });
    let count = 0;
    let ecount = 0;
    for (let x = 1; x < `${parseInt(args) + 1}`; x++) {
      msg.guild.roles.create({ data: { name: x, color: "RANDOM" } });
    }
  }
});

client.on("message", async (msg) => {
    if(msg.author.bot) return;
    let substringArray = get_substrings_between(msg.content, ":", ":");
    let message = msg.content;
    if(!substringArray.length) return;
    substringArray.forEach(m => {
        let emoji = client.emojis.cache.find(x => x.name === m);
        var replace = `:${m}:`;
        var rexreplace = new RegExp(replace, 'g');

        if(emoji && !msg.split(" ").find(x => x === emoji.toString()) && !msg.includes(`<a${replace}${emoji.id}>`)) msg = msg.replace(rexreplace, emoji.toString());
    })
    

    if(msg === msg.content) return;

    let webhook = await msg.channel.fetchWebhooks();
    webhook = webhook.find(x => x.name === "NIRO_NQN");

    if(!webhook) {
        webhook = await msg.channel.createWebhook(`NIRO_NQN`, {
            avatar: client.user.displayAvatarURL({dynamic: true})
        });
    }

    await webhook.edit({
        name: msg.member.nickname ? msg.member.nickname : msg.author.username,
        avatar: msg.author.displayAvatarURL({dynamic: true})
    })

    msg.delete().catch(m => {})

    webhook.send(msg).catch( m => {});

    await webhook.edit({
        name: `NIRO_NQN`,
        avatar: client.user.displayAvatarURL({dynamic:true})
    })

 
})

function get_substrings_between(str, startDelimiter, endDelimiter) {
    var contents = [];
    var startDelimiterLength = startDelimiter.length;
    var endDelimiterLength = endDelimiter.length;
    var startFrom = contentStart = contentEnd = 0;
  
    while (false !== (contentStart = strpos(str, startDelimiter, startFrom))) {
      contentStart += startDelimiterLength;
      contentEnd = strpos(str, endDelimiter, contentStart);
      if (false === contentEnd) {
        break;
      }
      contents.push(str.substr(contentStart, contentEnd - contentStart));
      startFrom = contentEnd + endDelimiterLength;
    }
  
    return contents;
  }
  
  
  function strpos(haystack, needle, offset) {
    var i = (haystack + '').indexOf(needle, (offset || 0));
    return i === -1 ? false : i;
  }

client.on("message", async (msg) => {
  if (msg.content.startsWith(prefix + "games")) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setTitle(error + " **You Can't Use This Command In DM!**"))
    msg.channel.send(lodeing + " **Processing data ...**").then((m) => {
      m.edit(success + " **Processing is complete**")
    })
                  if (cooldown_command.has(msg.author.id)) {
            msg.reply(new Discord.MessageEmbed().setDescription(`**${msg.author.username},  Cooldown : 5 seconds**`))
        } else {
    msg.channel.send(new Discord.MessageEmbed().setTitle("**Bot Orders**").setThumbnail(msg.member.user.avatarURL({ format: "gif", format: "png", dynamic: true, size: 1024 }))
      .addField(prefix + "fkk", "fkk game", true)
      .addField(prefix + "fast", "fast game", true)
      .addField(prefix + "translation", "translation game", true)
      .addField(prefix + "sara7a", "sara7a game", true)
      .addField(prefix + "frots", "frots game", true)
      .addField(prefix + "8ball", "8ball game", true)
      .addField(prefix + "cut", "cut twwet game", true)
      .addField(prefix + "flag", "flag game", true)
      .addField(prefix + "emoji", "emoji game", true)
      .addField(prefix + "brand", "brand game", true)
      .addField(prefix + "capitals", "capitals game", true)
      .addField(prefix + "rps", "rps game", true)
      .addField(prefix + "xo", "xo game", true)
      .addField(prefix + "puzzle", "puzzle game", true)
      .addField(prefix + "math", "math game", true)
      .setFooter(`need more info? just type ${prefix}help [cmd name]`)
    )
                cooldown_command.add(msg.author.id);
            setTimeout(() => {
                cooldown_command.delete(msg.author.id);
            }, 5000)
        }
  }
})

client.on("message", niro_games => {

  if (
    niro_games.content == prefix + "fkk" ||
    niro_games.content == prefix + "فكك"
  ) {
    var x = ["https://media.discordapp.net/attachments/798926497490010112/798926550124462110/2021-47-13_04__47__35.png", "https://cdn.discordapp.com/attachments/798926497490010112/798926555040055296/2021-43-13_04__43__14.png", "https://cdn.discordapp.com/attachments/798926497490010112/798926555811282954/2021-45-13_04__45__08.png", "https://cdn.discordapp.com/attachments/798926497490010112/798926559041814528/2021-45-13_04__45__27.png", "https://cdn.discordapp.com/attachments/798926497490010112/798926546609242162/2021-47-13_04__47__18.png", "https://cdn.discordapp.com/attachments/798926497490010112/798926561549615174/2021-45-13_04__45__42.png", "https://cdn.discordapp.com/attachments/798926497490010112/798926565554913290/2021-45-13_04__45__50.png", "https://cdn.discordapp.com/attachments/798926497490010112/798926564728635402/2021-46-13_04__46__05.png", "https://cdn.discordapp.com/attachments/798926497490010112/798926565475876874/2021-47-13_04__47__06.png"];
    var x2 = ["ا ل ق م د", "ا ل ق م ر", "ح م ا د ه", "ا ل ف ر ع و ن", "ا خ و ا ت ي", "م ع ك ر و ن ه", "ب ي ض", "ا ل م و ت", "ن ي ر و"]
    var x3 = Math.floor(Math.random() * x.length);
    var brand = new Discord.MessageEmbed()
      .setImage(`${x[x3]}`, true)
      .setTitle(`**اسرع شخص يرسل تفكيك الكلمة خلال __10__ ثواني**`, true);

    niro_games.reply(brand).then(msg1 => {
      var r = niro_games.channel.awaitMessages(msg => msg.content == x2[x3], {
        max: 1,
        time: 20000,
        errors: ["time"]
      });
      r.catch(() => {
        return niro_games.channel
          .send(
            new Discord.MessageEmbed()
              .setTitle(`**${error}لقد انتهى الوقت ولم يقم أحد بالأجابة بشكل صحيح الصحيحة هيا __${x2[x3]}__ **`)
          );
      });

      r.then(collected => {
        
        niro_games.reply(
          new Discord.MessageEmbed()
            .setTitle(` لقد قمت بأرسال التفكيك في الوقت المناسب`)
        );
      });
    });
  }
});


client.on("message", niro_games => {

  if (
    niro_games.content == prefix + "puzzle" ||
    niro_games.content == prefix + "لغز"
  ) {
    var x = ["https://cdn.discordapp.com/attachments/798926497490010112/798944666762477588/PicsArt_01-13-06.00.32.png", "https://cdn.discordapp.com/attachments/798926497490010112/798945106409160764/PicsArt_01-13-06.02.21.png", "https://cdn.discordapp.com/attachments/798926497490010112/798942961655611412/PicsArt_01-13-05.52.59.png", "https://cdn.discordapp.com/attachments/798926497490010112/798943832401379338/PicsArt_01-13-05.57.15.png", "https://cdn.discordapp.com/attachments/798926497490010112/798941596015132712/1610551137976.png"];
    var x2 = ["تموز", "المسمار", "البيضه", "العمر", "السلحفة"]
    var x3 = Math.floor(Math.random() * x.length);
    var brand = new Discord.MessageEmbed()
      .setImage(`${x[x3]}`, true)
      .setTitle(`**اسرع شخص يحل الغز في خلال __10__ ثواني**`);

    niro_games.reply(brand).then(msg1 => {
      var r = niro_games.channel.awaitMessages(msg => msg.content == x2[x3], {
        max: 1,
        time: 20000,
        errors: ["time"]
      });
      r.catch(() => {
        return niro_games.channel
          .send(
            new Discord.MessageEmbed()
              .setTitle(`**${error}لقد انتهى الوقت ولم يقم أحد بالأجابة بشكل صحيح الصحيحة هيا __${x2[x3]}__ **`, true)
          );
      });

      r.then(collected => {
        
        niro_games.reply(
          new Discord.MessageEmbed()
            .setTitle(`**لقد قمت باحل الغز في الوقت المناسب**`)
        );
      });
    });
  }
});


client.on("message", niro_games => {

  if (
    niro_games.content == prefix + "fast" ||
    niro_games.content == prefix + "اسرع"
  ) {//"1","2","3","4","5","6","7","8","9"
    var x = ["https://cdn.discordapp.com/attachments/798926497490010112/798948125607854080/2021-10-13_06__10__31.png", "https://cdn.discordapp.com/attachments/798926497490010112/798948132149788692/2021-10-13_06__10__50.png", "https://cdn.discordapp.com/attachments/798926497490010112/798948138585030656/2021-11-13_06__11__14.png", "https://cdn.discordapp.com/attachments/798926497490010112/798948139226628099/2021-11-13_06__11__56.png", "https://cdn.discordapp.com/attachments/798926497490010112/798948142732410920/2021-12-13_06__12__14.png", "https://cdn.discordapp.com/attachments/798926497490010112/798948145425022996/2021-12-13_06__12__26.png", "https://cdn.discordapp.com/attachments/798926497490010112/798948147153207316/2021-14-13_06__14__14.png7", "https://cdn.discordapp.com/attachments/798926497490010112/798948146418810890/2021-12-13_06__12__52.png", "https://cdn.discordapp.com/attachments/798926497490010112/798948145437736980/2021-12-13_06__12__36.png"];
    var x2 = ["نيرو", "القمر", "المحلة", "نار", "سرير", "قولون", "الأسماعيليه", "القاهره", "الأسكندر"]
    var x3 = Math.floor(Math.random() * x.length);
    var brand = new Discord.MessageEmbed()
      .setImage(`${x[x3]}`)
      .setTitle(`**اسرع شخص يرسل العاصمه خلال __10__ ثواني**`);
    
    niro_games.reply(brand).then(msg1 => {
      var r = niro_games.channel.awaitMessages(msg => msg.content == x2[x3], {
        max: 1,
        time: 20000,
        errors: ["time"]
      });
      r.catch(() => {
        return niro_games.channel
          .send(
            new Discord.MessageEmbed()
              .setTitle(`**${error}لقد انتهى الوقت ولم يقم أحد بالأجابة بشكل صحيح الصحيحة هيا __${x2[x3]}__ **`)
          );
      });

      r.then(collected => {
        
        niro_games.reply(
          new Discord.MessageEmbed()
            .setTitle(`**لقد قمت بأرسال الكلمة في الوقت المناسب**`)
        );
      });
    });
  }
});


client.on("message", niro_games => {

  if (
    niro_games.content == prefix + "math" ||
    niro_games.content == prefix + "رياضيات"
  ) {
    var x = ["https://cdn.discordapp.com/attachments/798926497490010112/798949965610090567/2021-21-13_06__21__41.png", "https://cdn.discordapp.com/attachments/798926497490010112/798950267521466398/2021-23-13_06__23__00.png", "https://media.discordapp.net/attachments/798926497490010112/798950456050843668/2021-23-13_06__23__41.png", "https://cdn.discordapp.com/attachments/798926497490010112/798950748809461770/2021-24-13_06__24__51.png", "https://cdn.discordapp.com/attachments/798926497490010112/798950982905888809/2021-25-13_06__25__50.png"];
    var x2 = ["2000", "26", "14", "5.3", "12"]
    var x3 = Math.floor(Math.random() * x.length);
    var brand = new Discord.MessageEmbed()
      .setImage(`${x[x3]}`)
      .setTitle(`**اسرع شخص يرسل الحل خلال __10__ ثواني**`);

    niro_games.reply(brand).then(msg1 => {
      var r = niro_games.channel.awaitMessages(msg => msg.content == x2[x3], {
        max: 1,
        time: 20000,
        errors: ["time"]
      });
      r.catch(() => {
        return niro_games.channel
          .send(
            new Discord.MessageEmbed()
              .setTitle(`**${error}لقد انتهى الوقت ولم يقم أحد بالأجابة بشكل صحيح الصحيحة هيا __${x2[x3]}__ **`)
          );
      });

      r.then(collected => {
        
        niro_games.reply(
          new Discord.MessageEmbed()
            .setTitle(`**لقد قمت بأرسال الحل في الوقت المناسب**`)
        );
      });
    });
  }
});


client.on("message", niro_games => {

  if (
    niro_games.content == prefix + "capitals" ||
    niro_games.content == prefix + "عواصم"
  ) {
    var x = ["https://cdn.discordapp.com/attachments/798926497490010112/798951739687960646/2021-28-13_06__28__29.png", "https://cdn.discordapp.com/attachments/798926497490010112/798952044719243304/2021-30-13_06__30__03.png", "https://cdn.discordapp.com/attachments/798926497490010112/798951871486099516/2021-28-13_06__28__29.png", "https://cdn.discordapp.com/attachments/798926497490010112/798951510582886420/2021-27-13_06__27__49.png", "https://cdn.discordapp.com/attachments/798926497490010112/798951367917174874/2021-27-13_06__27__18.png", "https://cdn.discordapp.com/attachments/798926497490010112/798951194633699359/2021-26-13_06__26__36.png"];
    var x2 = ["القاهره", "برازيليا", "اوتاوا", "الرياض", "دمشق", "القدس"]
    var x3 = Math.floor(Math.random() * x.length);
    var brand = new Discord.MessageEmbed()
      .setImage(`${x[x3]}`)
      .setTitle(`**اسرع شخص يرسل العاصمه خلال __10__ ثواني**`);

    niro_games.reply(brand).then(msg1 => {
      var r = niro_games.channel.awaitMessages(msg => msg.content == x2[x3], {
        max: 1,
        time: 20000,
        errors: ["time"]
      });
      r.catch(() => {
        return niro_games.channel
          .send(
            new Discord.MessageEmbed()
              .setTitle(`**${error}لقد انتهى الوقت ولم يقم أحد بالأجابة بشكل صحيح الصحيحة هيا __${x2[x3]}__ **`)
          );
      });

      r.then(collected => {
        
        niro_games.reply(
          new Discord.MessageEmbed()
            .setTitle(`**لقد قمت بأرسال العاصمة في الوقت المناسب**`)
        );
      });
    });
  }
});


client.on("message", niro_games => {
  
  if (
    niro_games.content == prefix + "brand" ||
    niro_games.content == prefix + "شعار"
  ) {
    var x = [
      "https://cdn.discordapp.com/attachments/756329106953601225/776584216161812490/jW4dnFtA_400x400.png",
      "https://cdn.discordapp.com/attachments/756329106953601225/776589087997296691/InCS8dvy_400x400.png",
      "https://cdn.discordapp.com/attachments/756329106953601225/776590445622329344/ocZKRu9P_400x400.png",
      "https://cdn.discordapp.com/attachments/756329106953601225/776591027943243776/aCWlGSZF_400x400.png"
    ];
    var x2 = ["جافا", "ريزر", "يوتيوب", "جوجل كروم"];
    var x3 = Math.floor(Math.random() * x.length);
    var brand = new Discord.MessageEmbed()
      .setImage(`${x[x3]}`)
      .setTitle(`**اسرع شخص يرسل الاشعار خلال __10__ ثواني**`);

    niro_games.reply(brand).then(msg1 => {
      var r = niro_games.channel.awaitMessages(msg => msg.content == x2[x3], {
        max: 1,
        time: 20000,
        errors: ["time"]
      });
      r.catch(() => {
        return niro_games.channel
          .send(
            new Discord.MessageEmbed()
              .setTitle(`${error}لقد انتهى الوقت ولم يقم أحد بالأجابة بشكل صحيح 
            الصحيحةة هيا **${x2[x3]}**`)
          );
      });

      r.then(collected => {
        
        niro_games.reply(
          new Discord.MessageEmbed()
            .setTitle(`**لقد قمت ب أرسال الشعار في الوقت المناسب**`)
        );
      });
    });
  }
});
    

client.on("message", niro_games => {
  
  if (
    niro_games.content == prefix + "flag" ||
    niro_games.content == prefix + "اعلام"
  ) {
    var x = [
      "https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Flag_of_Brazil.svg/256px-Flag_of_Brazil.svg.png",
      "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c0/Flag_of_Jordan.svg/256px-Flag_of_Jordan.svg.png",
      "https://cdn.discordapp.com/attachments/756329106953601225/776908227476062258/images_4.png",
      "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Flag_of_Senegal.svg/1200px-Flag_of_Senegal.svg.png"
    ];
    var x2 = ["البرازيل", "الاردن", "مصر", "السنغال"];
    var x3 = Math.floor(Math.random() * x.length);
    var flag = new Discord.MessageEmbed()
      .setImage(`${x[x3]}`)
      .setTitle(`**اسرع شخص يرسل العلم خلال __10__ ثواني**`);
    niro_games.reply(flag).then(msg1 => {
      var r = niro_games.channel.awaitMessages(msg => msg.content == x2[x3], {
        max: 1,
        time: 20000,
        errors: ["time"]
      });
      r.catch(() => {
        return niro_games.channel
          .send(
            new Discord.MessageEmbed()
              .setTitle(`${error}**لقد انتهى الوقت ولم يقم أحد بالأجابة بشكل صحيح 
            الصحيحةة هيا** ***${x2[x3]}***`)
          );
      });

      r.then(collected => {
        
        niro_games.reply(
          new Discord.MessageEmbed()
            .setTitle(`**لقد قمت بالاجابه بشكل صحيح**`)
        );
      });
    });
  }
});
    

const cuttweet = [
  "كت تويت ‏| تخيّل لو أنك سترسم شيء وحيد فيصبح حقيقة، ماذا سترسم؟",
  "كت تويت | أكثر شيء يُسكِت الطفل برأيك؟",
  "كت تويت | الحرية لـ ... ؟",
  "كت تويت | قناة الكرتون المفضلة في طفولتك؟",
  "كت تويت ‏| كلمة للصُداع؟",
  "كت تويت ‏| ما الشيء الذي يُفارقك؟",
  "كت تويت | موقف مميز فعلته مع شخص ولا يزال يذكره لك؟",
  "كت تويت ‏| أيهما ينتصر، الكبرياء أم الحب؟",
  "كت تويت | بعد ١٠ سنين ايش بتكون ؟",
  "كت تويت ‏| مِن أغرب وأجمل الأسماء التي مرت عليك؟",
  "‏كت تويت | عمرك شلت مصيبة عن شخص برغبتك ؟",
  "كت تويت | أكثر سؤال وجِّه إليك مؤخرًا؟",
  "‏كت تويت | ما هو الشيء الذي يجعلك تشعر بالخوف؟",
  "‏كت تويت | وش يفسد الصداقة؟",
  "‏كت تويت | شخص لاترفض له طلبا ؟",
  "‏كت تويت | كم مره خسرت شخص تحبه؟.",
  "‏كت تويت | كيف تتعامل مع الاشخاص السلبيين ؟",
  "‏كت تويت | كلمة تشعر بالخجل اذا قيلت لك؟",
  "‏كت تويت | جسمك اكبر من عٌمرك او العكسّ ؟!",
  "‏كت تويت |أقوى كذبة مشت عليك ؟",
  "‏كت تويت | تتأثر بدموع شخص يبكي قدامك قبل تعرف السبب ؟",
  "كت تويت | هل حدث وضحيت من أجل شخصٍ أحببت؟",
  "‏كت تويت | أكثر تطبيق تستخدمه مؤخرًا؟",
  "‏كت تويت | ‏اكثر شي يرضيك اذا زعلت بدون تفكير ؟",
  "‏كت تويت | وش محتاج عشان تكون مبسوط ؟",
  "‏كت تويت | مطلبك الوحيد الحين ؟",
  "‏كت تويت | هل حدث وشعرت بأنك ارتكبت أحد الذنوب أثناء الصيام؟"
];

client.on("message", niro_games => {
  
  if (
    niro_games.content.startsWith(prefix + "cut") ||
    niro_games.content.startsWith(prefix + "كت")
  ) {
    if (!niro_games.channel.guild)
      return niro_games.reply("** This command only for servers**");
    var embed = new Discord.MessageEmbed()
      .setThumbnail(niro_games.author.avatarURL())
      .addField(
        "لعبه كت تويت",
        `${cuttweet[Math.floor(Math.random() * cuttweet.length)]}`
      );
    niro_games.reply(embed);

    console.log("[id] Send By: " + niro_games.author.username);
  }
});
    

client.on("message", niro_games => {
  
  if (
    niro_games.content == prefix + "emoji" ||
    niro_games.content == prefix + "ايموجي"
  ) {
    var x = ["🌚", "😂", "🥶", "😷", "🌻", "🌗", "✨", "🍐", "🚗", "💽"];
    var x2 = ["🌚", "😂", "🥶", "😷", "🌻", "🌗", "✨", "🍐", "🚗", "💽"];
    var x3 = Math.floor(Math.random() * x.length);
    var emoji = new Discord.MessageEmbed()
      .setTitle(`** لديك __10 ثواني__ لكتابة الايموجي **`)
      .addField(`${x[x3]}`);
    niro_games.reply(emoji).then(msg1 => {
      var r = niro_games.channel.awaitMessages(msg => msg.content == x2[x3], {
        max: 1,
        time: 20000,
        errors: ["time"]
      });
      r.catch(() => {
        return niro_games.channel
          .send(
            new Discord.MessageEmbed()
              .setTitle(`:negative_squared_cross_mark:** لقد انتهى الوقت ولم يقم أحد بالأجابة بشكل صحيح 
            الصحيحة هيا __${x2[x3]}__ **`)
          );
      });

      r.then(collected => {
        
        niro_games.reply(
          new Discord.MessageEmbed()
            .setTitle(`**لقد قمت بكتابة الايموجي في الوقت المناسب**`)
        );
      });
    });
  }
});
    

client.on("message", msg => {
  if (msg.author.bot) return;
  if (msg.content.startsWith(prefix + "xo")) {
    let array_of_mentions = msg.mentions.users.array();
    let symbols = [":o:", ":heavy_multiplication_x:"];
    var grid_message;

    if (array_of_mentions.length == 1 || array_of_mentions.length == 2) {
      let random1 = Math.floor(Math.random() * (1 - 0 + 1)) + 0;
      let random2 = Math.abs(random1 - 1);
      if (array_of_mentions.length == 1) {
        random1 = 0;
        random2 = 0;
      }
      var player1_id = msg.author.id;
      let player2_id = array_of_mentions[random2].id;
      var turn_id = player1_id;
      var symbol = symbols[0];
      let initial_message = `اللعبة بين اللاعبين التاليين <@${player1_id}> and <@${player2_id}>!`;
      if (player1_id == player2_id) {
        initial_message += "\n_(لقد خسرت, العب مع نفسك :joy:)_";
      }
      msg.channel
        .send(`Xo ${initial_message}`)
        .then(console.log("Successful tictactoe introduction"))
        .catch(console.error);
      msg.channel
        .send(
          ":one::two::three:" +
          "\n" +
          ":four::five::six:" +
          "\n" +
          ":seven::eight::nine:"
        )
        .then(new_message => {
          grid_message = new_message;
        })
        .then(console.log("Successful tictactoe game initialization"))
        .catch(console.error);
      msg.channel
        .send("Loading... Please wait for the :ok: reaction.")
        .then(async new_message => {
          await new_message.react("1⃣");
          await new_message.react("2⃣");
          await new_message.react("3⃣");
          await new_message.react("4⃣");
          await new_message.react("5⃣");
          await new_message.react("6⃣");
          await new_message.react("7⃣");
          await new_message.react("8⃣");
          await new_message.react("9⃣");
          await new_message.react("🆗");
          await new_message
            .edit(`It\'s <@${turn_id}>\'s اشتغل! الرمز هو ${symbol}`)
            .then(new_new_message => {
              require("./xo.js")(
                niro,
                message,
                new_new_message,
                player1_id,
                player2_id,
                turn_id,
                symbol,
                symbols,
                grid_message
              );
            })
            .then(
              console.log("Successful tictactoe listeprefix initialization")
            )
            .catch(console.error);
        })
        .then(console.log("Successful tictactoe react initialization"))
        .catch(console.error);
    } else {
      msg.channel
        .send(`جرب *xo @uesr`)
        .then(console.log("Successful error reply"))
        .catch(console.error);
    }
  }
});
    

client.on("message", function(niro_games) {
  
  if (niro_games.content.startsWith(prefix + "rps")) {
    let messageArgs = niro_games.content
      .split(" ")
      .slice(1)
      .join(" ");
    let messageRPS = niro_games.content
      .split(" ")
      .slice(2)
      .join(" ");
    let arrayRPS = ["**# - Rock**", "**# - Paper**", "**# - Scissors**"];
    let result = `${arrayRPS[Math.floor(Math.random() * arrayRPS.length)]}`;
    var RpsEmbed = new Discord.MessageEmbed()
      .setAuthor(niro_games.author.username)
      .setThumbnail(niro_games.author.avatarURL())
      .addField("Rock", "🇷", true)
      .addField("Paper", "🇵", true)
      .addField("Scissors", "🇸", true);
    niro_games.reply(RpsEmbed).then(msg => {
      msg.react("🇸");
      msg.react("🇷");
      msg
        .react("🇵")
        .then(() => msg.react("🇸"))
        .then(() => msg.react("🇷"))
        .then(() => msg.react("🇵"));
      let reaction1Filter = (reaction, user) =>
        reaction.emoji.name === "🇸" && user.id === niro_games.author.id;
      let reaction2Filter = (reaction, user) =>
        reaction.emoji.name === "🇷" && user.id === niro_games.author.id;
      let reaction3Filter = (reaction, user) =>
        reaction.emoji.name === "🇵" && user.id === niro_games.author.id;
      let reaction1 = msg.createReactionCollector(reaction1Filter, {
        time: 12000
      });

      let reaction2 = msg.createReactionCollector(reaction2Filter, {
        time: 12000
      });
      let reaction3 = msg.createReactionCollector(reaction3Filter, {
        time: 12000
      });
      reaction1.on("collect", r => {
        niro_games.reply(result);
      });
      reaction2.on("collect", r => {
        niro_games.reply(result);
      });
      reaction3.on("collect", r => {
        niro_games.reply(result);
      });
    });
  }
});
    

client.on("message", async niro_games => {
  
  if (niro_games.author.bot) return;
  if (niro_games.channel.type === "dm") return;

  let messageArray = niro_games.content.split(" ");
  let cmd = messageArray[0];
  let args = messageArray.slice(1);

  if (cmd === prefix + `8ball`) {
    if (!args[1]) return niro_games.reply("Please ask a full question!");
    let replies = ["Yes", "No.", "I don't know.", "Ask again later plez."];

    let result = Math.floor(Math.random() * replies.length);
    let question = args.slice(1).join(" ");

    let ballembed = new Discord.MessageEmbed()
      .setAuthor(niro_games.author.tag)
      .addField("Question", question)
      .addField("Answer", replies[result]);

    niro_games.reply(ballembed);
  }
});
    

client.on("message", niro_games => {
  

  if (
    niro_games.content.startsWith(prefix + "frots") ||
    niro_games.content.startsWith(prefix + "فواكه")
  ) {
    let slot1 = ["🍏", "🍇", "🍒", "🍍", "🍅", "🍆", "🍑", "🍓"];
    let slots1 = `${slot1[Math.floor(Math.random() * slot1.length)]}`;
    let slots2 = `${slot1[Math.floor(Math.random() * slot1.length)]}`;
    let slots3 = `${slot1[Math.floor(Math.random() * slot1.length)]}`;
    let we;
    if (slots1 === slots2 && slots2 === slots3) {
      we = "Win!";
    } else {
      we = "Lose!";
    }
    niro_games.reply(`${slots1} | ${slots2} | ${slots3} - ${we}`);
  }
});
    

const Sra7a = [
  "صراحه  |  صوتك حلوة؟",
  "صراحه  |  التقيت الناس مع وجوهين؟",
  "صراحه  |  شيء وكنت تحقق اللسان؟",
  "صراحه  |  أنا شخص ضعيف عندما؟",
  "صراحه  |  هل ترغب في إظهار حبك ومرفق لشخص أو رؤية هذا الضعف؟",
  "صراحه  |  يدل على أن الكذب مرات تكون ضرورية شي؟",
  "صراحه  |  أشعر بالوحدة على الرغم من أنني تحيط بك كثيرا؟",
  "صراحه  |  كيفية الكشف عن من يكمن عليك؟",
  "صراحه  |  إذا حاول شخص ما أن يكرهه أن يقترب منك ويهتم بك تعطيه فرصة؟",
  "صراحه  |  أشجع شيء حلو في حياتك؟",
  'صراحه  |  طريقة جيدة يقنع حتى لو كانت الفكرة خاطئة" توافق؟',
  "صراحه  |  كيف تتصرف مع من يسيئون فهمك ويأخذ على ذهنه ثم ينتظر أن يرفض؟",
  "صراحه  |  التغيير العادي عندما يكون الشخص الذي يحبه؟",
  "صراحه  |  المواقف الصعبة تضعف لك ولا ترفع؟",
  "صراحه  |  نظرة و يفسد الصداقة؟",
  "صراحه  |  ‏‏إذا أحد قالك كلام سيء بالغالب وش تكون ردة فعلك؟",
  "صراحه  |  شخص معك بالحلوه والمُره؟",
  "صراحه  |  ‏هل تحب إظهار حبك وتعلقك بالشخص أم ترى ذلك ضعف؟",
  "صراحه  |  تأخذ بكلام اللي ينصحك ولا تسوي اللي تبي؟",
  "صراحه  |  وش تتمنى الناس تعرف عليك؟",
  "صراحه  |  ابيع المجرة عشان؟",
  "صراحه  |  أحيانا احس ان الناس ، كمل؟",
  "صراحه  |  مع مين ودك تنام اليوم؟",
  "صراحه  |  صدفة العمر الحلوة هي اني؟",
  'صراحه  |  الكُره العظيم دايم يجي بعد حُب قوي " تتفق؟',
  "صراحه  |  صفة تحبها في نفسك؟",
  'صراحه  |  ‏الفقر فقر العقول ليس الجيوب " ، تتفق؟',
  "صراحه  |  تصلي صلواتك الخمس كلها؟",
  "صراحه  |  ‏تجامل أحد على راحتك؟",
  "صراحه  |  اشجع شيء سويتة بحياتك؟",
  "صراحه  |  وش ناوي تسوي اليوم؟",
  "صراحه  |  وش شعورك لما تشوف المطر؟",
  "صراحه  |  غيرتك هاديه ولا تسوي مشاكل؟",
  "صراحه  |  ما اكثر شي ندمن عليه؟",
  "صراحه  |  اي الدول تتمنى ان تزورها؟",
  "صراحه  |  متى اخر مره بكيت؟",
  "صراحه  |  تقيم حظك ؟ من عشره؟",
  "صراحه  |  هل تعتقد ان حظك سيئ؟",
  "صراحه  |  شـخــص تتمنــي الإنتقــام منـــه؟",
  "صراحه  |  كلمة تود سماعها كل يوم؟",
  "صراحه  |  **هل تُتقن عملك أم تشعر بالممل؟",
  "صراحه  |  هل قمت بانتحال أحد الشخصيات لتكذب على من حولك؟",
  "صراحه  |  متى آخر مرة قمت بعمل مُشكلة كبيرة وتسببت في خسائر؟",
  "صراحه  |  ما هو اسوأ خبر سمعته بحياتك؟",
  "‏صراحه | هل جرحت شخص تحبه من قبل ؟",
  "صراحه  |  ما هي العادة التي تُحب أن تبتعد عنها؟",
  "‏صراحه | هل تحب عائلتك ام تكرههم؟",
  "‏صراحه  |  من هو الشخص الذي يأتي في قلبك بعد الله – سبحانه وتعالى- ورسوله الكريم – صلى الله عليه وسلم؟",
  "‏صراحه  |  هل خجلت من نفسك من قبل؟",
  "‏صراحه  |  ما هو ا الحلم  الذي لم تستطيع ان تحققه؟",
  "‏صراحه  |  ما هو الشخص الذي تحلم به كل ليلة؟",
  "‏صراحه  |  هل تعرضت إلى موقف مُحرج جعلك تكره صاحبهُ؟",
  "‏صراحه  |  هل قمت بالبكاء أمام من تُحب؟",
  "‏صراحه  |  ماذا تختار حبيبك أم صديقك؟",
  "‏صراحه  | هل حياتك سعيدة أم حزينة؟",
  "صراحه  |  ما هي أجمل سنة عشتها بحياتك؟",
  "‏صراحه  |  ما هو عمرك الحقيقي؟",
  "‏صراحه  |  ما اكثر شي ندمن عليه؟",
  "صراحه  |  ما هي أمنياتك المُستقبلية؟‏",
  "صراحه | نفسك فـ ايه ؟",
  "صراحه | هل تحب فتاه او احببت من قبل ؟",
  "صراحه | هل شكلك حلو او جيد او متوسط او سئ ؟",
  "صراحه | ما هي الماده الدراسيه التي تحبها اكثر وتفضلها؟",
  "صراحه | هل تحب مدرستك ؟",
  "صراحه | ما الشئ الذي تتمني ان يحصل ؟",
  "صراحه | هل تحب عائلتك ؟"
];
client.on("message", niro_games => {
  
  if (niro_games.author.bot) return;
  if (niro_games.content.startsWith(prefix + "sara7a")) {
    if (!niro_games.channel.guild)
      return niro_games.reply("** This command only for servers **");
    var niro = new Discord.MessageEmbed()
      .setTitle("لعبة صراحة ..")
      .setDescription(`${Sra7a[Math.floor(Math.random() * Sra7a.length)]}`)
      .setImage(
        "https://cdn.discordapp.com/attachments/371269161470525444/384103927060234242/125.png"
      )
      .setTimestamp();

    niro_games.reply(niro);
  }
});
    

client.on("message", niro_games => {
  
  if (
    niro_games.content == prefix + "translation" ||
    niro_games.content == prefix + "ترجمه"
  ) {
    var x = [
      "Constantinople",
      "Clever",
      "apple",
      "day",
      "browser",
      "cocked",
      "Tomatoes",
      "Connect",
      "coconut"
    ];
    var x2 = [
      "القسطنطينيه",
      "ذكي",
      "تفاح",
      "يوم",
      "متصفح",
      "مطبوخ",
      "طماطم",
      "اتصال",
      "ك"
    ];
    var x3 = Math.floor(Math.random() * x.length);
    var emoji = new Discord.MessageEmbed()
      .setTitle(`** لديك __10 ثواني__ لكتابة الترجمه**`)
      .addField(`${x[x3]}`);
    niro_games.reply(emoji).then(msg1 => {
      var r = niro_games.channel.awaitMessages(msg => msg.content == x2[x3], {
        max: 1,
        time: 20000,
        errors: ["time"]
      });
      r.catch(() => {
        return niro_games.channel
          .send(
            new Discord.MessageEmbed()
              .setTitle(`:negative_squared_cross_mark:** لقد انتهى الوقت ولم يقم أحد بالأجابة بشكل صحيح 
            الصحيحة هيا __${x2[x3]}__ **`)
          );
      });

      r.then(collected => {
        
        niro_games.reply(
          new Discord.MessageEmbed()
            .setTitle(`** لقد قمت بكتابة الترجمه في الوقت المناسب **`)
        );
      });
    });
  }
}); 

client.login(token).catch(err => { console.error(`[ Discord ] Worng Token :<`) })